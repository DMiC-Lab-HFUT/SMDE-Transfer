function [bound,dimension] = loadProPara(casedata,numDynGen,Pmax, Pmin)
if(strcmpi(casedata,'case30') || strcmpi(casedata,'dcase30'))
    dimension=11;
    bound=[ 0.95 0.95 0.95 0.95 0.95  0 0 0 0 1 1;
         1.1 1.1 1.1 1.1 1.1  20 20 20 20 30 30];
    bound=bound';
elseif(strcmp(casedata,'case57')|| strcmpi(casedata,'dcase57'))
    Xmin=[Pmin, 0.95*ones(1,7-numDynGen),0*ones(1,17),1*ones(1,3)];
    Xmax=[Pmax, 1.1*ones(1,7-numDynGen),20*ones(1,17),30*ones(1,3)];
    bound=[Xmin;Xmax];
    bound=bound';
    dimension=numel(Xmin);    
elseif(strcmp(casedata,'case118')|| strcmpi(casedata,'dcase118'))
    Xmin=[Pmin, 0.95*ones(1,54-numDynGen),0*ones(1,9),1*ones(1,12)];
    Xmax=[Pmax, 1.1*ones(1,54-numDynGen),20*ones(1,9),30*ones(1,12)];
    bound=[Xmin;Xmax];
    bound=bound';
    dimension=numel(Xmin);   
else
    disp('wrong casedata');
    keyboard;
end
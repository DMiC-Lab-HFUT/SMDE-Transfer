function [N_pre, N_mem, N_rnd,N_last, MemIdSet] = new_determine_pop_percentage3(tarClu,mu, mu_last_env, NP)
%% The following is to determine the percentage of memory
...and random solutions in the new population based on the
    ...fuzzy similarity.
global memory;
MemIdSet_index = tarClu;
num_envs = 1:numel(memory);
MemIdSet = num_envs(MemIdSet_index);
N_pre=NP;
N_mem=ceil(mu*NP);
N_last=ceil(mu_last_env*NP);
if N_mem+N_last>=NP
    N_rnd=0;
else
    N_rnd=NP-N_mem-N_last;
end

end
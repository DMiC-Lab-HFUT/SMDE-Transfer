function  save2mem(loads, PG, pop, popFit, popG, swarm)
global g_memory;
global gbest;
global gbestfit;
global gbestcons;
global memory;
global memorynow;
global numChanges;
global g_caseconfig;
global method;

numMemElements=numel(memory);

if method == 1  || method == 2
    flag = sum(gbestcons)<=1e-10;
else
    flag = 1;
end
if flag%sum(gbestcons)<=1e-10
    numMemElements=numMemElements+1;
    memory(numMemElements).bestLoc =gbest;
    memory(numMemElements).bestFit =gbestfit;
    memory(numMemElements).bestCon =gbestcons;
    numSpe=numel(swarm);
    preSeedsIndex=zeros(numSpe,1);
    for i = 1:numSpe
        preSeedsIndex(i) = swarm(i).seedID;
    end
    index=sum(popG(preSeedsIndex,:), 2) <= 1e-10;
    index=preSeedsIndex(index);
    %��õĽ�+���е�����
    memory(numMemElements).localMemory =[gbest; pop(index,:)];
    memory(numMemElements).LMFit =[gbestfit; popFit(index,:)];
    memory(numMemElements).LMCon =[gbestcons; popG(index,:)];
    memory(numMemElements).LMsize=size( memory(numMemElements).localMemory,1);%��¼һ�´�С
      %ʣ�µĿ��и������
    %�����ΪmemPop
    index2=sum(popG(:,:), 2) <= 1e-10;
    index2(index)=0;
    memory(numMemElements).memPop=pop(index2,:);
    memory(numMemElements).memPopFit=popFit(index2,:);
    memory(numMemElements).memPopG=popG(index2,:);
    memory(numMemElements).memsize=size( memory(numMemElements).memPop,1);%��¼һ�´�С
     %������Ⱥ����ʣ�µĸ���
    index3=sum(popG(:,:), 2) > 1e-10;
    memory(numMemElements).pop=pop(index3,:);
    memory(numMemElements).popFit=popFit(index3,:);
    memory(numMemElements).popG=popG(index3,:);
    %������Ⱥ
    memory(numMemElements).pop=pop(:,:);
    memory(numMemElements).popFit=popFit(:,:);
    memory(numMemElements).popG=popG(:,:);
    
    %��������
    memory(numMemElements).PG=PG';
    memory(numMemElements).indics = g_caseconfig.indics;
    memory(numMemElements).indics_gen = g_caseconfig.indics_gen;
    memory(numMemElements).sev = g_caseconfig.sev;
    memory(numMemElements).prob_gen = g_caseconfig.prob_gen;
    memory(numMemElements).loads=loads';
    memory(numMemElements).numChanges=numChanges;
    memory(numMemElements).time=0;%not used
    memory(numMemElements).numLM=numel(index)+1;
end
if isempty(g_memory)
    g_memory(1,:)=[loads, PG, gbest, gbestfit, gbestcons];
    return;
end
dimloads=numel(loads);
dimvar=numel(gbest);
dimPG=numel(PG);
try
    disToMemory=pdist2(g_memory(:,1:dimloads+dimPG),[loads,PG]);
catch
    keyboard;
end
match= find(disToMemory<1e-5);
index_fitness = dimloads+dimPG+dimvar+1;
index_vio = index_fitness+1:index_fitness+3;
num = size(g_memory,1);
if ~isempty(match)
    ibest=debbest(g_memory(match,index_fitness),g_memory(match,index_vio));
    best=g_memory(match(ibest),:);
    g_memory(match,:)=[];
    if debbetter(gbestfit,gbestcons,best(index_fitness),best(index_vio))
        g_memory(num+1,:)=[loads,PG,gbest,gbestfit,gbestcons];
    else
        g_memory(num+1,:)=best;
    end
else
    g_memory(num+1,:)=[loads, PG, gbest, gbestfit, gbestcons];
end

end
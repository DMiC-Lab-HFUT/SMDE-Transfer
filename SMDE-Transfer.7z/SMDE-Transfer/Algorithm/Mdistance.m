function d=Mdistance(X,Y)
S = cov(X);
mu = mean(X);
d = (Y-mu)*inv(S)*(Y-mu)';
d = ((Y-mu)/S)*(Y-mu)'; % <-- Mathworks prefers this way
end
 % The Ensemble of SF SR EC and SP constraint handling methods
clear all;
global  nfeval
format long e;
tic
D=12;
NP=15;


Xmin=[0.95 0.95 0.95 0.95 0.95 0.95  0 0 0 0 1 1];
Xmax=[1.1 1.1 1.1 1.1 1.1 1.1  20 20 20 20 30 30];

Max_FES=10000;
Max_Gen=400;
gn = 3;
feval = [];
     
 for runs=1:10 
     
   fprintf('Run %d',runs);
   nfeval=0;
   
 
   pop=repmat(Xmin,NP,1)+repmat((Xmax-Xmin),NP,1).*rand(NP,D);
   for i=1:NP
      [val(i,1),g(i,:)] = rpflow(pop(i,:));
   end
   
   nfeval=nfeval+NP;
   
  ub=repmat(Xmax,NP,1);
  lb=repmat(Xmin,NP,1);
 
  rot=(0:1:NP-1); 


for gen=1:Max_Gen
   
   
    FM_mui = rand(NP,D) < 0.9; 
    FM_mpo = FM_mui < 0.5;   
    ind=randperm(2);
    FVr_a1 = randperm(NP); 
    rt=rem(rot+ind(1),NP);
    FVr_a2 = FVr_a1(rt+1);
    rt=rem(rot+ind(2),NP);
    FVr_a3 = FVr_a2(rt+1);
                      
   
    newpop(1:NP,:)=pop(FVr_a1,:)+ 0.7*(pop(FVr_a2,:)-pop(FVr_a3,:));
    for i=1:NP
      
        for kk=1:D
            if(newpop(i,kk) < Xmin(kk))
                newpop(i,kk)= Xmin(kk)+( Xmax(kk)- Xmin(kk)).*rand;
            end
            if(newpop(i,kk) > Xmax(kk))
               newpop(i,kk)= Xmin(kk)+( Xmax(kk)- Xmin(kk)).*rand;
           end
        end
    end
    newpop = pop.*FM_mpo + newpop.*FM_mui;   
               
     for i=1:NP
      [newval(i,1),newg(i,:)] = rpflow(newpop(i,:));
    end             
     
    nfeval=nfeval+NP;
        
    
              
        A=[pop;newpop];
        B=[val;newval];
        G=[g;newg];
        
    
   % Superiority of Feasible Solutions
    cons=[(G>0).*G]; 
    cons_max=max(cons,[],1);
    nzindex=find(cons_max~=0);
    
    if isempty(nzindex)
        tcons=zeros(size(A,1),1);
    else

        tcons=sum(cons(:,nzindex)./repmat(cons_max(:,nzindex),size(A,1),1),2)./sum(1./cons_max(:,nzindex));
    end 
    
    
 
    for kk=1:NP
        
        if(((tcons(NP+kk)<tcons(kk)) | ((tcons(NP+kk)==0) & (tcons(kk)==0) & (B(NP+kk)<=B(kk)))))
        
            pop(kk,:)= A(NP+kk,:);
            val(kk,:)= B(NP+kk,:);
            g(kk,:)  = G(NP+kk,:);
            ttcons(kk,:) = tcons(NP+kk,:);
        else
            ttcons(kk,:) = tcons(kk,:);
            
        end
       
       
    end
        
        
  feasindex=find(ttcons==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(ttcons);
    gbestval=val(ibest);
    gbest = pop(ibest,:);
  else
    [gbestval,ibest]=min(val(feasindex));
    gbesttcons=ttcons(feasindex(ibest));
    gbest = pop(feasindex(ibest),:);
  end

    if(gen ==1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  elseif((gbesttcons < thegbesttcons) | (gbesttcons==0 & thegbesttcons ==0 & gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  end
    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;    
    
  if(isempty(feval) && thegbesttcons ==0)
        feval = nfeval;
    end
end

%eval(['save D:\PLOSS\PLOSS30\SFDE\W_' int2str(runs) ' W;']);
Re(runs,1)=gbestval;
Re(runs,2)=gbesttcons;
Re(runs,3)=feval;

end

Res(1)=max(Re(:,1));
Res(2)=min(Re(:,1));
Res(3)=median(Re(:,1));
Res(4)=mean(Re(:,1));
Res(5)=std(Re(:,1)); 
Res(6)=mean(Re(:,3));

%eval(['save D:\PLOSS\PLOSS30\SFDE\FUN']);
toc
        

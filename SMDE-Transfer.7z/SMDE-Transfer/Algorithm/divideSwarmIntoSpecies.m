function [swarm, numSpe]=divideSwarmIntoSpecies(pop, popFit, popG, method, phi)
global numUnchanged_SpeNum;
global preSpeNum;
global gmaxcons;
global nIter_k_means;
global nIter;
global threshold_value;
if isempty(numUnchanged_SpeNum)
    numUnchanged_SpeNum=0;
end
if isempty(nIter_k_means)
    nIter_k_means=0;
end
[NP, DIM]=size(pop);

% threshold_value=5;

if numUnchanged_SpeNum < threshold_value || method==1 || method >= 6
    % sort the swarm in descending order
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([popFit, cons],[2, 1]);
    %distance calculation
    distanceMatrix=zeros(NP,NP);
    for i=1:NP
        distanceMatrix(i,i+1:NP) = pdist2(pop(index(i),:), pop(index(i+1:NP),:));        
    end
    distanceMatrix=distanceMatrix+distanceMatrix';
    
    [swarm, numSpe]=NBC(distanceMatrix, index, phi);
    
    for i=1:numSpe
        swarm(i).seedLoc = pop(swarm(i).seedID,:);
    end
    
    if preSpeNum == numSpe
        numUnchanged_SpeNum = numUnchanged_SpeNum + 1;  
    else
        numUnchanged_SpeNum = 0;
    end      
    preSpeNum = numSpe;
else
    
    nIter_k_means=nIter_k_means+1;
    numSpe = numel(swarm);
    seeds=zeros(numSpe, DIM);
    loop = 0;
    for i = 1:numSpe
%         if numUnchanged_SpeNum > threshold_value || ~(swarm(i).size <= 2 && swarm(i).rank > (NP/2))
            loop = loop + 1;
            seeds(loop,:)=swarm(i).seedLoc;
%         end
    end
    seeds(loop+1:end,:)=[];
    numUnchanged_SpeNum=numUnchanged_SpeNum+1;
    [swarm, numSpe] = twoStepNearestSeedsClustering(pop, popFit, popG, seeds);
end
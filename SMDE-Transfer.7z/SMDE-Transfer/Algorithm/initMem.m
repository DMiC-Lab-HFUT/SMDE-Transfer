function initMem(casedata,usearchive,num_cbus,numDynGen,case_renewablePower)
global g_memory;
global optimalValues;
global memory;

if(usearchive==1)
%     folder='';
%     file=[folder,'archive_',casedata,'_nbus',num2str(num_cbus),'_ngen',...
%                 num2str(numDynGen),'_Power',num2str(case_renewablePower),'.mat'];
%     load(file, 'g_memory');
%     optimalValues=g_memory;
%     g_memory=[];
    folder='data\init_memory\';
    file=[folder,'archive_',casedata,'_nbus',num2str(num_cbus),'_ngen'...
                 num2str(numDynGen),'_Power',num2str(case_renewablePower),'_run1','.mat'];%,'_sevPD',num2str(changeprob),'_sevPG',num2str(prob_gen)
    load(file, 'g_memory','memory');
%     num=min(size(memory, 1),num);
%     memory = memory(1, 1:num);
%     num=min(size(g_memory, 1),num);
%     g_memory = g_memory(1:num, :);
    
elseif usearchive==2
    g_memory=[];
    memory=[];
    optimalValues=[];
end
function vpop=memImmigrants(numImm,bound)
% memory strategy: mean-based immigrants
% the mean of memory is used as immigrant center, std as immigrant radius
% input:
%   numImm: the number of immigrants to be generated
%   bound: the boundary of the varaibles
% output:
%   vpop: the generated individuals using this strategy
global g_memory;% structure: <loads, PG, variables, fitness, cons>
global g_caseconfig;
global s2;
if isempty(g_memory)
    vpop=[];
    return
end

index_varaibles=(numel(g_caseconfig.indics)+numel(g_caseconfig.indics_gen)+1):(size(g_memory,2)-4);

if size(g_memory,1)==1
    vcenter=g_memory(1,index_varaibles);
    vstd=zeros(1,numel(index_varaibles));
else
    vcenter=mean(g_memory(:,index_varaibles));
    vstd=std(g_memory(:,index_varaibles));
end

matcenter=repmat(vcenter,numImm,1);
try
    %generate immigrants
    vpop=matcenter+repmat(vstd,numImm,1).*randn(s2,numImm,numel(vstd));    
catch message
    disp(message.message);
    keyboard;
end
% handling boundary violation
boundUp=repmat(bound(:,2)',numImm,1);
exceedUp=vpop>boundUp;
boundLow=repmat(bound(:,1)',numImm,1);
exceedLow=vpop<boundLow;
vpop(exceedLow | exceedUp)=matcenter(exceedLow | exceedUp);
end
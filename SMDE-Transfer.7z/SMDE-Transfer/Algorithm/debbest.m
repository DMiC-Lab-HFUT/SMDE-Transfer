function [ibest,temp]=debbest(popFit,popG)
%% find the index of the best one according to Deb's rule
global gmaxcons;
if isempty(gmaxcons)
    maxcons=ones(1,size(popG,2));
else
    maxcons=gmaxcons;
end
NP=numel(popFit);
popG(popG<0)=0;
cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
feasindex=find(cons<1e-10);
if isempty(feasindex)
    [temp,ibest]=min(cons);
else
    [temp,ibest]=min(popFit(feasindex));
    ibest=feasindex(ibest);
end
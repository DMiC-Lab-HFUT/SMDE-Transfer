function [buschanged]=dynamic_bus(casedata)
global g_caseconfig;
global g_algpara;
global nfe;
global cgen;
global frequency;
global numChanges;
global case_renewablePower;
global flag_initMem;
global s2;
if isempty(frequency)
    frequency=100000;
end
if isempty(case_renewablePower)
    case_renewablePower=1;
end
%nargin < 2
%     has_change= false;
%     flag_initMem= false;
% elseif 
% if nargin < 1
%     has_change= false;
% end
buschanged=0;

if flag_initMem == true
    [buschanged]=dynamic_bus_forInitMem();
    return;
end

if (mod(nfe, frequency)== 0  && nfe > 0 && g_caseconfig.flag==1) 
    numChanges=numChanges+1;
    
%     disp(['numChanges: ',num2str(numChanges)]);

    buschanged=1;
    g_caseconfig.flag=0;
    baseloads=g_caseconfig.baseloads;
    delta=g_caseconfig.sev;
    
    
%     loads=baseloads.*( (2.*rand(s2,size(baseloads))-1).*delta ) + baseloads;    
     ideal_fileName=['data/Ideal_results/ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
     load(ideal_fileName, 'bestSolutionEachPeriod');
     optimalValues=bestSolutionEachPeriod; 
       if     numChanges==10
            loads =optimalValues(numChanges,6:10);
       else
           loads =optimalValues(numChanges+1,6:10);
       end
           
      
       loads=loads';
        
    g_caseconfig.formerloads=g_caseconfig.loads;
    g_caseconfig.loads=loads;   
    numDynGen = numel(cgen);
    %���ļ��ж�ȡ����������������ӵĲ�ͬ�������ⲻͬ
%     folder='data\';
%     if case_renewablePower == 1
%         file=[folder,'case_WindPower_casedata_',g_caseconfig.casename,'.mat'];
%     else
%         file=[folder,'case_SolarPower_casedata_',g_caseconfig.casename,'.mat'];
%     end
%     environments=load(file, 'g_caseconfig');
%     PG=environments.g_caseconfig.PG_all(:,numChanges);
    if     numChanges==10
        PG=optimalValues(numChanges,11:12);
    else
         PG=optimalValues(numChanges+1,11:12);
    end
   
    PG=PG';
    g_caseconfig.formerPG=g_caseconfig.PG;
    g_caseconfig.PG_all=[g_caseconfig.PG_all,g_caseconfig.PG];
    g_caseconfig.PG=PG;
end
end

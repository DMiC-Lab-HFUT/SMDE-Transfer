function [conv, ceq] = myCon(x)%,g
global casedata_LS;

[fitness,conv]=evaluateC(x,casedata_LS);

ceq=[];
end


function [fit,conv]=evaluateC(v,casedata)

%% return the fitness and the value of constraints violation
if (strcmpi(casedata,'case30') || strcmpi(casedata,'dcase30'))
        [fit,conv] = rpflow30(v,casedata);
elseif(strcmpi(casedata,'case57') || strcmpi(casedata,'dcase57'))
        [fit,conv] = rpflow57(v,casedata);
elseif(strcmpi(casedata,'case118') || strcmpi(casedata,'dcase118'));
        [fit,conv] = rpflow118(v,'dCase118');
else
    disp('wrong casedata');
    keyboard;
end

end


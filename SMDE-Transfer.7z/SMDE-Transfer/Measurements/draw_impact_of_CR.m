function draw_impact_of_CR()
%% Fig. 8
clear;
clear global;
clc;
currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\Algorithm']);
addpath([currentFolder,'\Measurements']);
addpath([currentFolder,'\Results\Measurements']);
folder_fig='Figures\';
%% Experimental settings
numChanges=10; % Total number of changes per run
methods=[1,6]; % To decide the set of compared algorithms
seeds=1:20; % the set of random seeds
% Note that if you want to change the settings of $num_cbus$ and $numDynGen$,
% the corresponding codes in the test problms should also be changed.
num_cbus =5; % the number of dynamic buses (to simulate the dynamics of demanded active power)
numDynGen=2; % the number of dynamic generator buses (to simulate the dynamics of renewable power generations)
probs={'dCase57', 'dCase118'};  % The set of test problems
numRuns=numel(seeds); % The total numbel of independent runs
changehandle=6;%not used
usearchive=2;%not used
numMemSize = 200;%not used

%% Parameter settings
phi=1.0; % The clustering parameter of NBC
DE_F_weight=0.85; % the scale factor F of DE
DE_CR=0.9; % crossover rate CR
NP=50; % the population size NP
threshold_value=7; %the parameter $gen_threshold$
nbc_parameter=2; %The parameter ��of the ��-NBC
DE_strategy=2; %  The DE mutation strategy
case_renewablePower=2; %1: ���ܷ���(Wind Power)  2��̫���ܷ��� (Solar Power)
DE_CR_weightSet=0.1:0.1:0.9;

folder='';

num=numel(DE_CR_weightSet);
num_algs = 7;%numel(methods);
feasibleTimeRatio_all=zeros(num_algs,num);
tracking_error_all=zeros(num_algs,num);

for i=1:2 % To decide the test problem (1: IEEE 57-bus; 2: IEEE 118-bus case )
    casedata = probs{i}; % the test problem
    loop = 0;
    for DE_CR= DE_CR_weightSet
        %disp(['SMEDE-I  nbc_parameter', num2str(nbc_parameter),' F: ',num2str(DE_F_weight)]);
        disp(['CR ',num2str(DE_CR)]);
        loop = loop + 1;
        
        for method = methods
            if method==1 &  case_renewablePower == 1
            fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
                num2str(numDynGen),'_NP',num2str(NP),'_phi',num2str(phi*10),...
                '_F',num2str(DE_F_weight),'_threshold',num2str(threshold_value),'_CR',num2str(DE_CR),'_nbc',num2str(nbc_parameter),'_Power',num2str(case_renewablePower)];
            else
                fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
                num2str(numDynGen),'_NP',num2str(NP),'_phi',num2str(phi*10),...
                '_F',num2str(DE_F_weight),'_threshold',num2str(threshold_value),'_CR',num2str(DE_CR),'_nbc',num2str(nbc_parameter),'_Power',num2str(case_renewablePower),'_DE2'];
       
            end
            outfile=[folder,fileName,'.mat'];
            load(outfile, 'feasibleTimeRatio','trackingError');
            feasibleTimeRatio_all(method+1,loop)=feasibleTimeRatio;
            tracking_error_all(method+1,loop)=trackingError;
        end
    end
    
     
    x=DE_CR_weightSet;
    ID=(i-1)*2+1;
    h=figure(ID);
    
    plot(x,feasibleTimeRatio_all(2,:),'m:x',x,feasibleTimeRatio_all(7,:));%'c--o',x,feasibleTimeRatio_all(2,:),'k-+',x,feasibleTimeRatio_all(3,:),'r-.*');
    
    set(gca, 'XTick', x);
    legend('SMDE-I','SMDE-Improved');
    
    xlabel('CR');
    ylabel('Feasible time ratio');
    
    str=[folder_fig,'\fig_8_',num2str(ID),'.eps'];
    saveas(h,str,'psc2');
    
    hold on;  
    
    
    x=DE_CR_weightSet;
    ID=(i-1)*2+2;
    h=figure(ID);
    
    plot(x,tracking_error_all(1,:),'m:x',x,tracking_error_all(6,:),'c--o');%,x,tracking_error_all(2,:),'k-+',x,tracking_error_all(3,:),'r-.*');
    
    set(gca, 'XTick', x);
    legend('SMDE-I','SMDE-Improved');
    
    xlabel('CR');
    ylabel('Tracking error');
    str=[folder_fig,'\fig_8_',num2str(ID),'.eps'];
    saveas(h,str,'psc2');
    
   
end

end
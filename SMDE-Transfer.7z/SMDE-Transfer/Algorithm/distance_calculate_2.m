function values=distance_calculate_2(x,y)
tmp=size(x);
row=tmp(1);
col=tmp(2);
values=zeros(row,1);
for i=1:row
    dis=0;
    for j=1:col
        dis=dis+(x(i,j)-y(1,j))^2;
    end
    values(i,:)=dis;
end
end
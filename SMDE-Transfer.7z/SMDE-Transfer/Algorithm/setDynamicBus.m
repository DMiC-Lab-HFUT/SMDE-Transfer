function [cbus, cgen]=setDynamicBus(num_bus, num_gen, casedata)
if(num_bus==1)
    if strcmpi(casedata,'dCase30')
        cbus=7;
    elseif strcmpi(casedata,'dCase57')
        cbus=47;
    elseif strcmpi(casedata,'dCase118')
        cbus=16;
    else
        keyboard;
    end
elseif (num_bus==5)
    if strcmpi(casedata,'dCase30')
        cbus=[7;19;21;24;30];
    elseif strcmpi(casedata,'dCase57')
        cbus=[10; 13; 16; 23; 32];
    elseif strcmpi(casedata,'dCase118')
        cbus=[11;45;60;78;82];
    else
        keyboard;
    end
end

if strcmpi(casedata,'dCase57')
    choice_gen_index = [2,3,4,6];
    if num_gen > numel(choice_gen_index)
        keyboard;
    end
    cgen=choice_gen_index(1:num_gen);
elseif strcmpi(casedata,'dCase118')    
    choice_gen_index = [2,4,5,6,10,11,12,13,14,18,19,20,21,22,25,26,28,29,30,32,33,37,39,40,41,42,44,45,49,51,52,53,54];
    if num_gen > numel(choice_gen_index)
        keyboard;
    end
    cgen=choice_gen_index(1:num_gen);
else
    keyboard;
end
cgen=cgen';
end
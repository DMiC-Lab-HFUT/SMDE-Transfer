function [best,updated]=getbest(algname)
g_algpara=getAlgLog(algname,'g_algpara');
idealstats=getAlgLog(algname,'idealstats');
single_run=getAlgLog(algname,'single_run');
updated=0;
NP=g_algpara.NP;
length=g_algpara.MaxNfe;
best=idealstats;
changetimes=idealstats(:,1);
j=1;
while j<numel(changetimes) && changetimes(j+1)<length
    lastgen=changetimes(j+1)/NP; %��j������������lastgen��
    if (best(j,2)>single_run(lastgen,1))
        best(j,2:5)=single_run(lastgen,1:4);
        updated=1;
    end
    j=j+1;
end

if j==numel(changetimes)
    lastgen=MaxNfe/NP;
    if (best(j,2)>single_run(lastgen,1))
        best(j,2:5)=single_run(lastgen,1:4);
        updated=1;
    end
end
    


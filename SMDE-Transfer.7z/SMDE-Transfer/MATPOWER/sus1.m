function count=sus1(normfit,NP)
    rr=rand;    
    spacing=1/NP;
    normfit=normfit/sum(normfit);
    randnums=sort(mod(rr:spacing:1+rr-0.5*spacing,1));  
    
    partsum=0;
    count=zeros(1,length(normfit));
    countsum=0;
    for i=1:length(normfit)
        partsum=partsum+normfit(i);
        count(i)=length(find(randnums<partsum))-countsum;
        countsum=countsum+count(i);
    end

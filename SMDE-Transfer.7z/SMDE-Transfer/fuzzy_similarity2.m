function [mu_sorted,mu_max, mu_last_env] = fuzzy_similarity2(loads, PG, flag_init)
%% The following is to calculate the fuzzy similarity between 
...the current environment and the previous environments
    
global dis_max; %TODO
global dis_min;%TODO
global k_logistic;;% structure: <loads, PG, variables, fitness, cons>
global memory;

if nargin < 3
    flag_init = 0;
end

mu_sorted=[];
mu_max=[];
mu_last_env=[];
k_logistic= 8;
dis_min=0;

if size(loads, 1) > 1
    loads=loads';
end
if size(PG, 1) > 1
    PG=PG';
end
%% 1. based on memory
if isempty(memory)
    return;
end

numMem = size(memory,1);
%index_variables=(numel(g_caseconfig.indics)+numel(g_caseconfig.indics_gen)+1):(size(memory,2)-4);
% distance
dif=memory(:,1:numel([loads, PG]))-repmat([loads, PG],size(memory,1),1);
means=mean(memory(:,1:numel([loads, PG])), 1);%modified by Chenyang Bu
normdif=abs(dif)./repmat(means,size(memory,1),1);
dis=sum(normdif,2);
mu_FuzzyDisVec=dis;%ģ�������ʼ��
for i=1:numMem
    if(dis(i) > dis_max)
        mu_FuzzyDisVec(i)=0;
    elseif(dis(i) < dis_min)
            mu_FuzzyDisVec(i) = 1;
    else
        tmpDis = (dis_max - dis(i))/dis_max;
        mu_FuzzyDisVec(i)=1.0/(1+exp(-1*k_logistic*(tmpDis-0.5)));
    end      
end

[mu_FuzzyDisVec_sorted,index]=sort(mu_FuzzyDisVec);
if flag_init ~= 0
    mu_last_env = mu_FuzzyDisVec_sorted(1);
else
    mu_last_env = mu_FuzzyDisVec(numMem);
end
mu_sorted.values = mu_FuzzyDisVec_sorted;
mu_sorted.id = index;
mu_max.value=mu_FuzzyDisVec_sorted(1);
mu_max.id=index(1);


end
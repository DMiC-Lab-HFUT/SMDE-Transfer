function [buschanged]=dynamic_bus_forInitMem()
global g_caseconfig;
global g_algpara;
global nfe;
global cgen;
global frequency;
global numChanges;
global case_renewablePower;
global s5;
if isempty(frequency)
    frequency=100000;
end
if isempty(case_renewablePower)
    case_renewablePower=1;
end
if nargin < 2
    has_change= false;
    flag_initMem= false;
elseif nargin < 1
    flag_initMem= false;
end
buschanged=0;

if (mod(nfe, frequency)== 0  && nfe > 0 && g_caseconfig.flag==1) || has_change == true
    numChanges=numChanges+1;
    
    %     disp(['numChanges: ',num2str(numChanges)]);
    
    buschanged=1;
    g_caseconfig.flag=0;
    baseloads=g_caseconfig.baseloads;
    %     delta=g_caseconfig.sev;
    %     loads=baseloads.*( (2.*rand(size(baseloads))-1).*delta ) + baseloads;
    delta=rand(s5);%g_caseconfig.sev;
    loads = baseloads.*( (2.*rand(s5, size(baseloads))-1).*delta ) + baseloads;
    
    g_caseconfig.formerloads=g_caseconfig.loads;
    g_caseconfig.loads=loads;
    
    numDynGen = numel(cgen);
    
    %case 1:ģ���������
    if case_renewablePower == 1
        %             a=11.0086;
        %             b=1.9622;
        %             v=wblrnd(a,b,numDynGen, 1);%����Τ���ֲ��������
        %             vci=4;
        %             vrate=13.61;
        %             vco=25;
        %             Prate = 40;
        %             PG=zeros(numDynGen, 1);
        %             for i=1:numDynGen
        %                 if v(i) <= vrate && v(i) >= vci
        %                     PG(i) = Prate * (v(i)-vci)/(vrate-vci);
        %                 elseif v(i) >= vrate && v(i) <= vco
        %                     PG(i) = Prate;
        %                 else
        %                     PG(i) = 0;
        %                 end
        %             end
        Prate = 40;
        
        vec = rand(s5, numDynGen, 1);
        PG = Prate * vec;
    else
        % case 2:ģ���������
        %             a=0.9;
        %             b=0.85;
        %             r_max=0.393;
        %             vec=betarnd(a,b,numDynGen, 1);%����Beta�ֲ��������
        %             r=vec*r_max;
        %             A=500;
        %             yita=0.14;
        %             PG=r*A*yita;
        r_max=0.393;
        vec = rand(s5, numDynGen, 1);
        %         vec=betarnd(a,b,numDynGen, 1);%����Beta�ֲ��������
        
        r=vec*r_max;
        A=500;
        yita=0.14;
        PG=r*A*yita;
    end
    
    g_caseconfig.formerPG=g_caseconfig.PG;
    g_caseconfig.PG_all=[g_caseconfig.PG_all,g_caseconfig.PG];
    g_caseconfig.PG=PG;
end
end

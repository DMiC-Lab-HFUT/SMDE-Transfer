function [best,fitbest,time,converge]= ASDE(nfe_max,F,CR,NP,pid)
%% adaptive schedule DE
tic;
global g_bestfit;
global temp;
global g_nfe;
global g_record;
global g_diverse;
global pop;
g_bestfit=999999;
temp=g_bestfit;
percentage=0;
if strcmpi(pid , 'CASE30')
    convergence=5.8;
elseif strcmpi(pid , 'case57')
    convergence=24;
elseif strcmpi(pid , 'case118')
    convergence=120;
else
    convergence=5.8;
end
wG=rand(NP,1);
[pop,bound,dimension]=z_initial(pid,NP);
[pop_fit] = z_evaluate(pop,NP,pid,bound);
[best,bestindex]=min(pop_fit);
g_nfe=0;
str_queue=[1,2,3,8];
numstr=numel(str_queue);
old_fit=zeros(1,numstr);
new_fit=ones(1,numstr);
NG=10;
t=0;
sng=ones(1,numstr);
while(g_nfe<nfe_max)
    delta_fitbest=new_fit-old_fit+0.000001;
    percentage=delta_fitbest./sng/sum(delta_fitbest./sng);
    sng=ones(1,numstr);
    winers=find(percentage>1/NG);
    sng(winers)=sng(winers)+sus1(percentage(winers),NG-numstr);
    
    for str=1:numstr
        old_fit(str)=g_bestfit;
        strategy=str_queue(str);
        for ng=1:sng(str)
            ind=randperm(4);
            rot=(0:NP-1);
            a1=randperm(NP);
            rt=rem(rot+ind(1),NP);
            a2=a1(rt+1);
            rt=rem(rot+ind(2),NP);
            a3=a2(rt+1);
            rt=rem(rot+ind(3),NP);
            a4=a3(rt+1);
            rt=rem(rot+ind(4),NP);
            a5=a4(rt+1);
            V1=pop(a1,:);
            V2=pop(a2,:);
            V3=pop(a3,:);
            V4=pop(a4,:);
            V5=pop(a5,:);
            if (strategy ==1)
                off=V1+F*(V2-V3);
            elseif strategy==2
                popFit1 = abs(pop_fit(a1));
                popFit2 = abs(pop_fit(a2));
                popFit3 = abs(pop_fit(a3));
                p1=popFit1./(popFit1+popFit2+popFit3);
                p2=popFit2./(popFit1+popFit2+popFit3);
                p3=popFit3./(popFit1+popFit2+popFit3);
                off=(V1+V2+V3)/3+repmat((p2-p1)',1,dimension).*(V1-V2)+repmat((p3-p2)',1,dimension).*(V2-V3)+repmat((p1-p3)',1,dimension).*(V3-V1);
            elseif strategy==3
                np=3;
                epsilon=1;
                P=zeros(np,dimension);
                P(1,:)=pop(bestindex,:);
                a=randint(np-1,1,[1,NP]);
                P(2:np,:)=pop(a(1:np-1),:);
                while(1)
                    O=sum(P)/np;
                    r=rand();
                    y1=O+epsilon.*(P(1,:)-O);
                    c=zeros(1,dimension);
                    for k=2:np
                        y2=O+epsilon*(P(k,:)-O);
                        c=(y1-y2+c)*r^(1/k);
                        y1=y2;
                    end
                    c=c+y2;
                    c_fit=z_evaluate(c,1,pid);
                    if  c_fit<best
                        P(1,:)=c;
                        best=c_fit;
                    else
                        pop(bestindex,:)=P(1,:);
                        pop_fit(bestindex)=best;
                        V1(a1==bestindex,:)=P(1,:);
                        V2(a2==bestindex,:)=P(1,:);
                        V3(a3==bestindex,:)=P(1,:);
                        off=V1+F*(V2-V3);
                        break;
                    end
                end
            elseif strategy==8
                alpha=0.7;
                beta=0.7;
                k=8;
                off=pop+alpha.*(repmat(pop(bestindex,:),NP,1)-pop)+beta.*(V1-V2);
                n=randperm(NP);
                n1=n+NP-k;
                n2=n+NP+k;
                for s=1:NP
                    m=[n1(s):n2(s)];
                    m=mod(m+NP-1,NP)+1;
                    [best,index]=min(pop_fit(m));
                    index=mod((index+n1(s)-2)+NP,NP)+1;
                    V1(s,:)=pop(s,:)+alpha.*(pop(index,:)-pop(s,:))+beta.*(V3(s,:)-V4(s,:));
                end
                wG1=wG+F.*(repmat(wG(bestindex),NP,1)-wG)+F.*(wG(a1)-wG(a2));
                wG1(find(wG1(:)>0.95))=0.95;
                wG1(find(wG1(:)<0.05))=0.05;
                off=repmat(wG,1,dimension).*off+repmat((1-wG),1,dimension).*V1;
            end
            
            %% crossover
            maskOff=rand(NP,dimension);
            off(find(maskOff>CR))=pop(find(maskOff>CR));
            %% bounder violation handling
            boundUp=repmat(bound(:,2)',NP,1);
            exceedUp=off>boundUp;
            offset=rand(NP,dimension).*(boundUp-pop);
            off(exceedUp)=pop(exceedUp)+offset(exceedUp);
            boundLow=repmat(bound(:,1)',NP,1);
            exceedLow=off<boundLow;
            offset=rand(NP,dimension).*(pop-boundLow);
            off(exceedLow)=pop(exceedLow)-offset(exceedLow);
            %% evaluation
            [off_fit] = z_evaluate(off,NP,pid,bound);
            succ=off_fit<pop_fit; % the indics of the successful offspring;
            pop(succ,:)= off(succ,:);
            pop_fit(succ)= off_fit(succ);
            %% end
            [best,bestindex]=min(pop_fit);
            if g_bestfit> convergence
                t=t+1;
            end
        end
        new_fit(str)=g_bestfit;
    end
end
converge=t
time=toc
figure(1);
plot(g_record,'-r.')
title(['��ֳ���30']);
xlabel('��������');
ylabel('��������ֵ');
grid
figure(2);
plot(g_diverse,'-r.')
title(['������30']);
xlabel('��������');
ylabel('������');
grid
disp(pop(bestindex,:));
disp(best);

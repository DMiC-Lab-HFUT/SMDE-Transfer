clear all
clc;
global g_record;
global g_nfe;
global g_bestfit;
global g_diverse;

strategy=1;
load expSetup.mat;
for run=1:RUN
    disp(['runDE CASE30 run ',num2str(run)]);
    [best,fitbest,time]=z_0de(strategy,c30_nfe,F,CR,NP,'CASE30');
    save(['DE_case30','_run',num2str(run),'_NP',num2str(NP),'.mat'],'g_record','g_diverse','best','time');
    
    disp(['runDE CASE57 run ',num2str(run)]);
    [best,fitbest,time]=z_0de(strategy,c57_nfe,F,CR,NP,'case57');
    save(['DE_case57','_run',num2str(run),'_NP',num2str(NP),'.mat'],'g_record','g_diverse','best','time');

    disp(['runDE CASE118 run ',num2str(run)]);
    [best,fitbest,time]=z_0de(strategy,c118_nfe,F,CR,NP,'case118');
    save(['DE_case118','_run',num2str(run),'_NP',num2str(NP),'.mat'],'g_record','g_diverse','best','time');

end
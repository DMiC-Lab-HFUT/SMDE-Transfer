function [fit,con_err]=econfcn30(xx)
global xl xu  n ng nb e1 e2
            global err_tol n_con
         global xu xl nb ng
          x=xx';
      x(7:10)=round(x(7:10));
      x(7:10)=[0.9 0.9 0.9 0.9]+ ...
                 [0.2 0.2 0.2 0.2].*x(7:10)./[20 20 20 20];
%x(64:77)=[-2	2	-5	5	5	5	5	3	2  2   2  2  6  6].*x(64:77);
%  x(7:63)=[0.9 0.9 0.9 0.9 0.9 0.9 0.9 0.9 0.9 ]+ ...
%           [0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 ].*x(55:63)./[20 20 20 20 20 20 20 20 20];
% x(64:77)=[-2	2	-5	5	5	5	5	3	2  2   2  2  6  6].*x(64:77);1.

baseMVA=100;
%for i=30
 %   x=xx(i,3:14);
%x=z(1,3:14)
 fp1=fopen('file1.dat','w');
fprintf(fp1,'%f\n',x);
fclose(fp1);

[baseMVA, bus, gen, branch, success, et, loss,ybus]=runpf('case30');
rloss=sum(real(loss)); %fitness fit1
Vmax=bus(:,12);
Vmin=bus(:,13);
genBUSnum=gen(:,1);
Qmin=gen(:,5)/100;
Qmax=gen(:,4)/100;
QGI=gen(:,3)/100;
limit=branch(:,6);
Slimit=sqrt(branch(:,12).^2+i*branch(:,13).^2);
Serr=sum((Slimit>limit).*abs(limit-Slimit))/baseMVA;
% TO find the error in Qg of gen buses- inequality constraint
Qerr=sum((QGI<Qmin).*(abs(Qmin-QGI)./(Qmax-Qmin))+(QGI>Qmax).*(abs(Qmax-QGI)./(Qmax-Qmin)));
% TO find the error in V of load buses- inequality constraint
VI=bus(:,8);  %V of load buses- inequality constraint
% vg=[1     4     6     8    10    12    15    18    19    24    25    26    27    31    32    34    36    40    42    46    49    54    55    56    59    61 ...
% 62    65    66    69    70    72    73    74    76    77    80    85    87    89    90    91    92    99   100   103   104   105   107   110   111   112   113   116];
vg=[1 2 5 8 11 13];
VI(vg)=[];
 Vmax(vg)=[];
  Vmin(vg)=[];
VIerr=sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
error(1)=Qerr;
error(2)=VIerr;
error(3)=Serr;
[ipq l]=sensitivity(ybus,bus,gen,branch);
%[ipq l]=L_index(x)
f1=rloss/100;
f2=max(l);
xerr=sum((x<xl').*(abs(xl'-x)./(xu'-xl'))+(x>xu').*(abs(xu'-x)./(xu'-xl')));
con_err=Qerr+VIerr+Serr+xerr;
tot=[f1 f2 error]
e1=x(1,1);
e2=x(1,2); 
fit=e1.*f1+e2.*f2;


function [output]=dSRDE(changehandler,casedata,num_DynBus,num_DynGen, ...
    fileName,MaxNfe,useArchive,run,strategy,numMemSize,NP,ChangeFrequency,phi_para,...
    DE_strategy, DE_F_weight,DE_CR,threshold_value_NSC,nbc_parameter,case_Power)
%% global declartion
clear global;
global nfe;
global cgen;
global g_caseconfig;
global intvRecord;
global preSpeNum;
global g_algpara;
global single_run;
global idealstats;
global gbestfit;
global nIter_noClustering;
global gbestcons;
global g_memory;
global fullrecord;
% global fullrecord1;
global trackingError;
global numChanges;
global numOfFeaGen;
global s1 s2  s3  s4;
global bestSolutionEachPeriodx;
global feasiblePeriods;
global numSpePerGen;
global nIter;
global method;
global is_calMem;
global bestPerformance;
global frequency;
global memory;
global optimalValues;
global nIter_k_means;
global seeds;
global factor;
global is_DEBUG;
global s5;
global gmaxcons;
global step;
global threshold_value;
global nbc_para;
global case_renewablePower;
global dis_max;
global s0;
global phi;
global caseData;
global memorynow;
caseData=casedata;
%% ���������
% ��������������У��ֱ����ڲ�ͬ�ķ������Թ�ƽ�Ƚ�
[s1,s2,s3,s4,s5] = RandStream.create('mrg32k3a','NumStreams',5,'Seed',run);
% s3: basicDE
%s2: initialSwarm; dSRDE
%s1: SUS
%s4:rand(s4)<Sr
% ������������ӹ̶�
[s0] = RandStream.create('mrg32k3a','Seed',0);
memorynow=[];

%% ��ʼ��
changestyle=1;%no use
changeprob=0.2;%no use
iscalcideal=1;%no use
prob_gen=1;%no use
[cbus, cgen]=setDynamicBus(num_DynBus, num_DynGen, casedata);
[Pmax, Pmin]=caseconfig(casedata,cbus,cgen,changeprob,changestyle,prob_gen);
[MaxNfe,Sr,changehandler]=loadAlgPara(MaxNfe,changehandler,iscalcideal,useArchive);
[bound,dimension]=loadProPara(casedata,num_DynGen,Pmax, Pmin);
% initMem(casedata,cbus,useArchive,changeprob,num_DynGen,run, numMemSize);
initMem(casedata,useArchive,num_DynBus,num_DynGen,case_Power);
[dis_max]=estimate_dis_max();
%% parameters settings
phi=phi_para;
case_renewablePower=case_Power;
g_caseconfig.casedata=casedata;
frequency=ChangeFrequency;
method=strategy;
preSpeNum=-1;
trackingError=0;
numChanges=0;
numOfFeaGen=0;
feasiblePeriods=0;
bestPerformance=0;
g_algpara.NP=NP;
intvRecord=NP;
g_algpara.algID=strategy;
factor=1.0-step;
threshold_value=threshold_value_NSC;
nfe=0;%number of function evaluations
numSpePerGen=zeros(round(MaxNfe/NP)+10,1);% for debug purpose
% single_run=zeros(round(MaxNfe/NP)+10,4+dimension);
popFit=zeros(NP,1);
offFit=popFit;
popG=zeros(NP,3);
offG=popG;
nbc_para=nbc_parameter;
is_DEBUG=1;
fullrecord=zeros(MaxNfe+10,4+dimension);
statsafterchange();

nIter=0;

if method == 0 
    [pop] = initialSwarm(NP,bound,dimension,useArchive);
    for i=1:NP
        [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata,fileName);
    end
else
    if useArchive == true
        [pop,popFit, popG] = initialPopWithMemory(NP,bound,dimension,casedata);
    elseif method == 3
        [pop] = initialSwarm(NP,bound,dimension,useArchive);
        for i=1:NP
            [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata,fileName);
        end
    else
        initSize = 2*NP;
        [pop] = initialSwarm(initSize,bound,dimension,useArchive);
        for i=1:initSize
            [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata,fileName);
        end
        if isempty(gmaxcons)
            maxcons=ones(1,size(popG,2));
        else
            maxcons=gmaxcons;
        end
        popG(popG<0)=0;
        cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
        [~,index]=sortrows([popFit, cons],[2, 1]);
        
        pop=pop(index(1:NP),:);
        popFit=popFit(index(1:NP),:);
        popG=popG(index(1:NP),:);
    end
    
end



off=pop;
tic;
nIter=1;
swarm=[];

pre_pop=pop;
pre_popFit=popFit;
pre_popG=popG;
while nfe<MaxNfe
    g_caseconfig.flag=1;
    changeoccur=0;
    %% basic DE
    if method == 0 || method == 3
        off=basicDE(pop, popFit, popG, DE_CR, DE_strategy, DE_F_weight);
    else
        [swarm, numSpe]=divideSwarmIntoSpecies(pop,popFit,popG,method,phi);
        numSpePerGen(nIter)=numSpe;
        for i=1:numSpe
            subSwarm=swarm(i).particles;
            [off(subSwarm,:)]=basicDE(pop(subSwarm,:),  popFit(subSwarm,:), popG(subSwarm,:), DE_CR, DE_strategy, DE_F_weight);
        end
    end
    
    %% -----------------Boundary violation handling-----------------%%
    boundUp=repmat(bound(:,2)',NP,1);
    exceedUp=off>boundUp;
    offset=rand(s2,NP,dimension).*(boundUp-pop);
    off(exceedUp)=pop(exceedUp)+offset(exceedUp);
    boundLow=repmat(bound(:,1)',NP,1);
    exceedLow=off<boundLow;
    offset=rand(s2,NP,dimension).*(pop-boundLow);
    off(exceedLow)=pop(exceedLow)-offset(exceedLow);
    % -----------------end boundary violation handling-----------------
    
    %% evaluation
    
    offFit = popFit;
    offG = popG;
    for i=1:NP
        [offFit(i,1),offG(i,:),changeoccur] = evaluate(off(i,:),casedata,fileName);
        if changeoccur
            break;
        end
    end
    
    %% Stochastic Selection
    %temporary matrixes
    A=[pop(1:NP,:);off(1:NP,:)];
    B=[popFit(1:NP,:);offFit(1:NP,:)];
    G=[popG(1:NP,:);offG(1:NP,:)];
    
    cons=(G>0).*G;
    cons_max=max(cons,[],1);
    nzindex=find(cons_max~=0);
    
    if isempty(nzindex)
        tcons=zeros(size(A,1),1);
    else
        tcons=sum(cons(:,nzindex)./repmat(cons_max(:,nzindex),size(A,1),1),2)./sum(1./cons_max(:,nzindex));
    end
    succ=zeros(NP,1);
    ttcons=zeros(NP,size(tcons,2));
    
    for kk=1:NP
        if(rand(s4)<Sr)
            if((B(NP+kk) < B(kk)))
                pop(kk,:)= A(NP+kk,:);
                popFit(kk,:)= B(NP+kk,:);
                popG(kk,:)  = G(NP+kk,:);
                ttcons(kk,:) = tcons(NP+kk,:);
                succ(kk)=1;
            else
                ttcons(kk,:) = tcons(kk,:);
            end
        else
            if((tcons(NP+kk) < tcons(kk)) || ((tcons(NP+kk)==0 && tcons(kk)==0) && (B(NP+kk) < B(kk))))
                pop(kk,:)= A(NP+kk,:);
                popFit(kk,:)= B(NP+kk,:);
                popG(kk,:)  = G(NP+kk,:);
                ttcons(kk,:) = tcons(NP+kk,:);
                succ(kk)=1;
            else
                ttcons(kk,:) = tcons(kk,:);
            end
        end
    end
    %--------------------End Stochastic selection
    
    %% action for changes
    if(changeoccur)
        [pop,popFit,popG,changeoccur]=actionForChange(changehandler,casedata,NP,pop,popFit,popG,swarm,useArchive,bound);
    end
    if sum(gbestcons)==0
        numOfFeaGen=numOfFeaGen+1;
    end
    nIter=nIter+1;
    %     pre_pop=pop;
    %     pre_popFit=popFit;
    %     pre_popG=popG;
end
time=toc;

folder='Results2\';

if exist(folder,'file')==0
    mkdir(folder);
end

trackingError=trackingError/feasiblePeriods;
output.numOfFeaGen=numOfFeaGen;
output.nIter=nIter;
output.trackingError=trackingError;
output.numChanges=numChanges;
output.feasiblePeriods=feasiblePeriods;
output.bestPerformance=bestPerformance;
output.time=time;
%bestSolutionEachPeriod
output.bestSolutionEachPeriod=bestSolutionEachPeriodx;
output.nIter_k_means=nIter_k_means;
output.nIter_noClustering=nIter_noClustering;


% outname=[casedata,'_alg',num2str(method),'_bus',num2str(numel(g_caseconfig.indics)),'_gen',num2str(numel(g_caseconfig.indics_gen))...
%     '_tau',num2str(g_caseconfig.prob(1)*100),'_NP',num2str(NP),'_phi',num2str(phi*10),'_cs',num2str(g_caseconfig.nstyle),'_ch',...
%     num2str(changehandler),'_ua',num2str(useArchive),'_run',num2str(run)];
% outfile=[folder,fileName,'.mat'];
% save(outfile);
% save(outfile,'single_run','g_caseconfig','g_algpara',...
%     'gbestfit','gbestcons','time','g_memory','fullrecord',...
%     'numOfFeaGen','nIter','trackingError','numChanges','nIter_k_means',...
%     'feasiblePeriods','bestSolutionEachPeriod','nIter_noClustering',...
%     'memory','output','optimalValues','bestPerformance','nfe','numSpePerGen','phi','NP');

% folder='data\';
% if exist(folder,'file')==0
%     mkdir(folder);
% end
% if case_renewablePower == 1
%     outfile=[folder,'case_WindPower_casedata_',g_caseconfig.casedata,'.mat'];
% else
%     outfile=[folder,'case_SolarPower_casedata_',g_caseconfig.casedata,'.mat'];
% end
% save(outfile,'g_caseconfig');
clear global;
end
function [N_pre, N_mem, N_rnd,N_last, MemIdSet] = new_determine_pop_percentage4(tarClu,mu, mu_last_env, NP)
%% The following is to determine the percentage of memory
...and random solutions in the new population based on the
    ...fuzzy similarity.
global memory;
MemIdSet_index = tarClu;
num_envs = 1:numel(memory);
MemIdSet = num_envs(MemIdSet_index);

N_pre=ceil(mu_last_env*NP);
N_last=N_pre;%no use
N_replace=NP-N_pre;%�滻�ĸ���
N_mem=ceil(N_replace*mu);%�������
N_rnd=N_replace-N_mem;%�������



end
function [off]=basicDE(pop, popFit, popG, F_CR, I_strategy, F_weight)
global s3;
% Author:           Rainer Storn, Ken Price, Arnold Neumaier, Jim Van Zandt
% Publication :     Price, K., Storn, R., Lampinen, J., Differential 
%                   Evolution - A Practical Approach to Global Optimization
%                   Springer, 2005
% Description:
% pop            the old population consisting of I_NP individuals
% off            the new population acquired by mutation and crossover
% F_weight        DE-stepsize F_weight ex [0, 2]
% F_CR            crossover probabililty constant ex [0, 1]
% I_strategy     1 --> DE/rand/1:
%                      the classical version of DE.
%                2 --> DE/local-to-best/1:
%                      a version which has been used by quite a number
%                      of scientists. Attempts a balance between robustness
%                      and fast convergence.
%                3 --> DE/best/1 with jitter:
%                      taylored for small population sizes and fast convergence.
%                      Dimensionality should not be too high.
%                4 --> DE/rand/1 with per-vector-dither:
%                      Classical DE with dither to become even more robust.
%                5 --> DE/rand/1 with per-generation-dither:
%                      Classical DE with dither to become even more robust.
%                      Choosing F_weight = 0.3 is a good start here.
%                6 --> DE/rand/1 either-or-algorithm:
%                      Alternates between differential mutation and three-point-
%                      recombination.

if nargin < 6
    F_weight = 0.85;
end
if nargin < 5
    I_strategy = 2;
end
if nargin < 4
    F_CR = 1;
end

[I_NP, I_D]=size(pop);

I_best_index=debbest(popFit,popG);
FVr_bestmemit = pop(I_best_index,:); % best member of current iteration

FM_bm    = zeros(I_NP,I_D);   % initialize FVr_bestmember  matrix

  for k=1:I_NP                              % population filled with the best member
    FM_bm(k,:) = FVr_bestmemit;             % of the last iteration
  end 

FVr_rot  = (0:1:I_NP-1);
FVr_ind = randperm(s3, 4);               % index pointer array

FVr_a1  = randperm(s3, I_NP);                   % shuffle locations of vectors
FVr_rt  = rem(FVr_rot+FVr_ind(1),I_NP);     % rotate indices by ind(1) positions
FVr_a2  = FVr_a1(FVr_rt+1);                 % rotate vector locations
FVr_rt  = rem(FVr_rot+FVr_ind(2),I_NP);
FVr_a3  = FVr_a2(FVr_rt+1);
FVr_rt  = rem(FVr_rot+FVr_ind(3),I_NP);
FVr_a4  = FVr_a3(FVr_rt+1);
FVr_rt  = rem(FVr_rot+FVr_ind(4),I_NP);
FVr_a5  = FVr_a4(FVr_rt+1);

FM_pm1 = pop(FVr_a1,:);             % shuffled population 1
FM_pm2 = pop(FVr_a2,:);             % shuffled population 2
FM_pm3 = pop(FVr_a3,:);             % shuffled population 3
FM_pm4 = pop(FVr_a4,:);             % shuffled population 4
FM_pm5 = pop(FVr_a5,:);             % shuffled population 5

%----Insert this if you want exponential crossover.----------------
%FM_mui = sort(FM_mui');	  % transpose, collect 1's in each column
%for k  = 1:NP
%  n = floor(rand(s3)*I_D);
%  if (n > 0)
%     FVr_rtd     = rem(FVr_rotd+n,I_D);
%     FM_mui(:,k) = FM_mui(FVr_rtd+1,k); %rotate column k by n
%  end
%end
%FM_mui = FM_mui';			  % transpose back
%----End: exponential crossover------------------------------------
FM_mui = rand(s3, I_NP, I_D) < F_CR;  % all random numbers < F_CR are 1, 0 otherwise
FM_mpo = FM_mui < 0.5;    % inverse mask to FM_mui

if (I_strategy == 1)                             % DE/rand/1
    off = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);   % differential variation
    off = pop.*FM_mpo + off.*FM_mui;     % crossover
elseif (I_strategy == 2)                         % DE/local-to-best/1
    off = pop + F_weight*(FM_bm-pop) + F_weight*(FM_pm1 - FM_pm2);
    off = pop.*FM_mpo + off.*FM_mui;
elseif (I_strategy == 3)                         % DE/best/1 with jitter
    off = FM_bm + (FM_pm1 - FM_pm2).*((1-0.9999)*rand(s3, I_NP,I_D)+F_weight);
    off = pop.*FM_mpo + off.*FM_mui;
elseif (I_strategy == 4)                         % DE/rand/1 with per-vector-dither
    f1 = ((1-F_weight)*rand(s3, I_NP,1)+F_weight);
    for k=1:I_D
        FM_pm5(:,k)=f1;
    end
    off = FM_pm3 + (FM_pm1 - FM_pm2).*FM_pm5;    % differential variation
    off = pop.*FM_mpo + off.*FM_mui;     % crossover
elseif (I_strategy == 5)                          % DE/rand/1 with per-vector-dither
    f1 = ((1-F_weight)*rand(s3)+F_weight);
    off = FM_pm3 + (FM_pm1 - FM_pm2)*f1;         % differential variation
    off = pop.*FM_mpo + off.*FM_mui;     % crossover
else                                              % either-or-algorithm
    if (rand(s3) < 0.5);                               % Pmu = 0.5
        off = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);% differential variation
    else                                           % use F-K-Rule: K = 0.5(F+1)
        off = FM_pm3 + 0.5*(F_weight+1.0)*(FM_pm1 + FM_pm2 - 2*FM_pm3);
    end
    off = pop.*FM_mpo + off.*FM_mui;     % crossover
end
end
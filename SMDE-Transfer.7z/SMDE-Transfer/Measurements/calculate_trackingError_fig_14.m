function [output]=calculate_trackingError_fig_14(maximum_error)
%% fig. 14
if nargin < 1
    maximum_error=2.5;
end

%% Preprocessing

clear global;
distcomp.feature( 'LocalUseMpiexec', false );
currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\data\Ideal_results']);
addpath([currentFolder,'\Algorithm']);
addpath([currentFolder,'\Measurements']);
addpath([currentFolder,'\Results\Measurements']);
addpath([currentFolder,'\Results_LS']);
folder='Results\';
if exist(folder,'file')==0
    mkdir(folder);
end
flag_parallel_run = true;% true, false
flag_test = false; % true, false

%% Experimental settings
numChanges=10; % Total number of changes per run
methods=[0:3]; % To decide the set of compared algorithms
seeds=1:20; % the set of random seeds
% Note that if you want to change the settings of $num_cbus$ and $numDynGen$,
% the corresponding codes in the test problms should also be changed.
num_cbus =5; % the number of dynamic buses (to simulate the dynamics of demanded active power)
numDynGen=2; % the number of dynamic generator buses (to simulate the dynamics of renewable power generations)
probs={'dCase57', 'dCase118'};  % The set of test problems
numRuns=numel(seeds); % The total numbel of independent runs
changehandle=6;%not used
usearchive=2;%not used
numMemSize = 200;%not used

if flag_test == true % For DEBUG purpose
    seeds = 1;
    numRuns=numel(seeds);
    numChanges=2;
    methods=0;
end

%% Parameter settings
phi=1.0; % The clustering parameter of NBC
DE_F_weight=0.85; % the scale factor F of DE
DE_CR=0.9; % crossover rate CR
NP=50; % the population size NP
threshold_value=7; %the parameter $gen_threshold$
nbc_parameter=2; %The parameter ��of the ��-NBC
DE_strategy=2; %  The DE mutation strategy
case_renewablePower=2;
casedata= probs{1};
numbus=5;
ideal_filename=['ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
load(ideal_filename, 'bestSolutionEachPeriod');
optimalValues=bestSolutionEachPeriod;


output=zeros(6,1);
%�ֱ��ȡtracking error
for method = 0:3   
    fileName=[casedata,'_method',num2str(method),'_bus',num2str(numbus),'_gen',...
        num2str(numDynGen),'_NP',num2str(NP),'_phi',num2str(phi*10),...
        '_F',num2str(DE_F_weight),'_threshold',num2str(threshold_value),'_CR',num2str(DE_CR),'_nbc',num2str(nbc_parameter),'_Power',num2str(case_renewablePower)];   
    
    % for fair comparisons, the medium results within the 20 runs were
    % selected to be presented
    outfile1=[folder,'Measurements\',fileName,'.mat'];
    load(outfile1, 'trackingError_all'); 
    array_to_sort=[trackingError_all, [1:20]'];
    [~, ind]=sort(array_to_sort,1);    
    seed=ind(10,1);   
    output(method+1)=seed;
    
    %load the results
    outfile=[folder,fileName,'_run',num2str(seed),'.mat'];
    
    fullrecord=load(outfile, 'fullrecord'); 
    fullrecord=fullrecord.fullrecord;
    
    
    changeFrequency = 5000;
    maxNfe= numChanges*changeFrequency;
    tracking_error_nfe=zeros(maxNfe,1);
    violation=zeros(maxNfe,1);
   
    %calculate the error per function evaluation
    for ii=1:maxNfe
        numChange=ceil(ii/changeFrequency);
        optimum = optimalValues(numChange,2);
        bestObtained = fullrecord(ii, 1);
        
        violation(ii) = sum(fullrecord(ii, 2:4));

        if(sum(fullrecord(ii, 2:4)))==0
            error=bestObtained-optimum;
            if error >= 0
                tracking_error_nfe(ii)=error;
            end
        else
            tracking_error_nfe(ii)= maximum_error;
        end
    end
    
    %     file=[folder,'Error_nfe_',casedata,'_nbus',num2str(numbus),'_sevPD',...
    %         num2str(prob),'_sevPG',num2str(prob_gen),'_gamma',num2str(gamma),'_run',num2str(seed),'.mat'];
    file=[folder,'Error_nfe_',casedata,'_method',num2str(method),'_run',num2str(seed),'.mat'];
    eval(['tracking_error_nfe_',num2str(method),'=tracking_error_nfe;']);
    eval(['violation_',num2str(method),'=violation;']);
    eval(['save(file,','''violation_',num2str(method),''',''tracking_error_nfe_',num2str(method),''');']);
end

for method = 4:5   
    fileName=[casedata,'_method',num2str(method),'_bus',num2str(numbus),'_gen',...
        num2str(numDynGen), '_renewablePower',num2str(case_renewablePower)];    
    % for fair comparisons, the medium results within the 20 runs were
    % selected to be presented
    outfile1=[fileName,'.mat'];
    load(outfile1, 'trackingError_all'); 
    array_to_sort=[trackingError_all, [1:20]'];
    [~, ind]=sort(array_to_sort,1);    
    seed=ind(10,1); 
    output(method+1)=seed;
     
    outfile=[fileName,'_run',num2str(seed),'.mat'];
    
    fullrecord=load(outfile, 'fullrecord'); 
    fullrecord=fullrecord.fullrecord;
    
    changeFrequency = 5000;
    numChanges=10;
    maxNfe= numChanges*changeFrequency;
    tracking_error_nfe=zeros(maxNfe,1);
    violation=zeros(maxNfe,1);
   
    for ii=1:maxNfe
        numChange=ceil(ii/changeFrequency);
        optimum = optimalValues(numChange,2);
        bestObtained = fullrecord(ii, 1);
        
        violation(ii) = sum(fullrecord(ii, 2:4));

        if(sum(fullrecord(ii, 2:4)))==0
            error=bestObtained-optimum;

            if error >= 0
                tracking_error_nfe(ii)=error;
            end
        else
            tracking_error_nfe(ii)= maximum_error;
        end
    end
    
    file=[folder,'Error_nfe_',casedata,'_method',num2str(method),'_run',num2str(seed),'.mat'];
    eval(['tracking_error_nfe_',num2str(method),'=tracking_error_nfe;']);
    eval(['violation_',num2str(method),'=violation;']);
    eval(['save(file,','''violation_',num2str(method),''',''tracking_error_nfe_',num2str(method),''');']);
end


end
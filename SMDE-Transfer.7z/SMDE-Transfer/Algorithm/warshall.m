function R=warshall(A)
n=size(A,1);
R=A;
for i=1:n
    for j=1:n
        if (R(j,i)==1)
            for k=1:n
                R(j,k)=logical(R(j,k)+R(i,k));
            end
        end
    end
end
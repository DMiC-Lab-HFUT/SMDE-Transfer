function [tarClu,mu, mu_last_env] = new_fuzzy_similarity2(pop,popFit,popG,loads, PG)
%��Ҫ�ش�����һ������ռ�����������ƾ����index������Ҫ���ֳ���ǰ����
%% The following is to calculate the fuzzy similarity between
...the current environment and the previous environments
    global method phi caseData intvRecord;
global dis_max; %TODO
global dis_min;%TODO
global k_logistic;
global g_memory;% structure: <loads, PG, variables, fitness, cons>
global memory;
NP=intvRecord;
numMem = size(memory,2)-1;
if numMem<1
    return;
end
tmp=size(memory(1).pop);
dimension=tmp(2);
if nargin < 3
    flag_init = 0;
end

mu_sorted=[];
mu_max=[];
mu_last_env=[];
k_logistic= 8;
dis_min=0;

if size(loads, 1) > 1
    loads=loads';
end
if size(PG, 1) > 1
    PG=PG';
end
%��ǰ�����ĸ�����
cur_dynamicPrams=[loads, PG];

[swarm, numSpe]=divideSwarmIntoSpecies(pop,popFit,popG,method,phi);%���������⣬��������ڲ��漰����̫����
cur_seeds =zeros(numSpe,dimension);
for i=1:numSpe
    cur_seeds(i,:)=pop(swarm(i).seedID,:);
end
cur_seedPositions=mean(cur_seeds,1);
cur_memoryFit=zeros(numMem,NP,1);
cur_memoryCons=zeros(numMem,NP,3);
for mem=1:numMem
    for i=1:NP
        [cur_memoryFit(mem,i,1),cur_memoryCons(mem,i,:)] = evaluate_cut(memory(mem).pop(i,:),caseData);
    end
end
cur_memoryFit(find(isnan(cur_memoryFit)==1)) = 0;
cur_memoryCons(find(isnan(cur_memoryCons)==1)) = 0;
%��ʷ�����ĸ�����
his_dynamicPrams=zeros(numMem,numel(loads)+numel(PG));
for i=1:numMem
    his_dynamicPrams(i,:) = [memory(i).loads',memory(i).PG'];
end
his_seeds = zeros(numMem,numSpe,dimension);
for i=1:numMem
    mPop=memory(i).pop;
    mPopFit=memory(i).popFit;
    mPopG=memory(i).popG;
    [swarm, numSpe]=divideSwarmIntoSpecies(mPop,mPopFit,mPopG,method,phi);%���������⣬��������ڲ��漰����̫����
    for j=1:numSpe
        his_seeds(i,j,:)=mPop(swarm(j).seedID,:);
    end
end
his_seedPositions=zeros(numMem,dimension);
for i=1:numMem
    temp=zeros(size(his_seeds,2),dimension);
    temp(:,:)=his_seeds(i,:,:);
    his_seedPositions(i,:)=mean(temp,1);
end
his_memoryFit=zeros(numMem,NP,1);
his_memoryCons=zeros(numMem,NP,3);
for mem=1:numMem
    his_memoryFit(mem,:,:)=memory(mem).popFit;
    his_memoryCons(mem,:,:)=memory(mem).popG;
end
his_memoryFit(find(isnan(his_memoryFit)==1)) = 0;
his_memoryCons(find(isnan(his_memoryCons)==1)) = 0;
%ŷ�ϡ������Ͼ�����㣬����������С������ֵʱ������ŷ�Ͼ��룬����ʱ�Ų������Ͼ���

if size(his_dynamicPrams,1)>=size(his_dynamicPrams,2)
    %���ȶ�����
    try
        dis_dynamicPrams=pdist2(his_dynamicPrams, repmat(cur_dynamicPrams,size(his_dynamicPrams,1),1), 'mahal');
        dis_dynamicPrams=dis_dynamicPrams(:,1);
    catch
        dis_dynamicPrams=sqrt(distance_calculate_2(his_dynamicPrams,cur_dynamicPrams));
    end
    
    %dis_dynamicPrams=mahal(his_dynamicPrams,repmat(cur_dynamicPrams,size(his_dynamicPrams,1),1) );
    
    
    %dis_dynamicPrams=pdist2(his_dynamicPrams, cur_dynamicPrams, 'mahal');
else
    dis_dynamicPrams=sqrt(distance_calculate_2(his_dynamicPrams,cur_dynamicPrams));
end

if size(his_seedPositions,1)>=size(his_seedPositions,2)
    dis_seedPositions=mahal(his_seedPositions,repmat(cur_seedPositions,size(his_seedPositions,1),1) );
    dis_seedPositions=dis_seedPositions';
else
    dis_seedPositions=sqrt(distance_calculate_2(his_seedPositions, cur_seedPositions));
end



if size(his_memoryFit,1)>=size(his_memoryFit,2)
    dis_memoryFit=pdist2(his_memoryFit, cur_memoryFit, 'mahal');
    dis_memoryFit=diag(dis_memoryFit);
else
    dis_memoryFit=distance_calculate_3(his_memoryFit, cur_memoryFit);
end

if size(his_memoryCons,1)>=size(his_memoryCons,2)
    dis_memoryCons=pdist2(his_memoryCons, cur_memoryCons, 'mahal');
    dis_memoryCons=diag(dis_memoryCons);
else
    dis_memoryCons=distance_calculate_3(his_memoryCons, cur_memoryCons);
end


%�ϲ�
dis_all=[dis_dynamicPrams,dis_seedPositions,dis_memoryFit,dis_memoryCons];
%��׼��
M=zeros(size(dis_all,1),size(dis_all,1));
for i =1:size(dis_all,2)
    MAX=max(dis_all(:,i));
    MIN=min(dis_all(:,i));
    dif=MAX-MIN;
    %��ֹֻ��һ����ʷ����
    if ~dif
        for j =1:size(dis_all,1)
            M(j,i)=1;
        end
    else
        for j =1:size(dis_all,1)
            M(j,i)=(dis_all(j,i)-MIN)/dif;
        end
    end
    
end
%���ƾ���ת��
temp_FM=transSimilarity(M,7);
FM=temp_FM;
%��հ�
for i=0:100000
    temp_FM=FM;
    FM=fuzzymm(FM,FM);
    if(FM==temp_FM)
        break;
    end
end
lmd=unique(FM);
lmd=sort(lmd);
if size(lmd,1)==1
    lmd=1;
else
    
    lmd=(lmd(1,1)+lmd(size(lmd,1)-1,1))/2;
end
pairs=[];
for i=1:size(FM,1)
    for j=1:i
        if(FM(i,j)>=lmd)
            pairs=[pairs;[i,j]];
        end
    end
end

mu=0;
tarClu=[];

for i=i:size(pairs,1)
    clu=[];
    cluLmd=[];
    clu=[clu,pairs(i,:)];
    cluLmd=[cluLmd,FM(pairs(i,1),pairs(i,2))];
    for j=1:size(pairs,1)
        if (~ismember(pairs(j,1),clu)&&ismember(pairs(j,2),clu))||(ismember(pairs(j,1),clu)&&~ismember(pairs(j,2),clu))
            clu=[clu,pairs(j,:)];
            cluLmd=[cluLmd,FM(pairs(j,1),pairs(j,2))];
        end
    end
    clu=unique(clu);
    cluLmd=unique(cluLmd);
    subM=M(clu,:);
    muA=0;
    for h=1:size(subM,1)
        for l=1:size(subM,2)
            muA=muA+((exp(1)-exp(subM(h,l)))/(exp(1)-1))/(size(subM,1)*size(subM,2));
        end
    end
    %muA=mean((exp(1)-exp(subM))./(exp(1)-1));%���任
    %muA=mean(1./subM);%����
    muB=mean(cluLmd);
    tempMu=muA*muB;
    if tempMu>=mu
        mu=tempMu;
        tarClu=clu;
    end
end

%[simIndex,lmd]=division(FM);
%[simIndex,lmd]=ada_division(dis_all,FM);
%t-1ʱ�����ƶ�
mu_last_env=mean((exp(1)-exp(M(size(FM,1),:)))./(exp(1)-1));

end


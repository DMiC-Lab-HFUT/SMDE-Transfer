function [newPop,popFit,popG,changeoccur]=changehandler6(pop,popFit,popG,bound,swarm,casedata)
global g_caseconfig;
global g_memory;
global gmaxcons;
global method;

changeoccur=0;
[NP, DIM]=size(pop);

save2mem(g_caseconfig.formerloads', g_caseconfig.PG', pop, popFit, popG,swarm);

if method == 3
    %% similar retrieval scheme
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% mean-based immigrants scheme
    numImmigrants = 10;
    imPop=memImmigrants(numImmigrants, bound);
    replacePool=[replacePool;imPop];
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    newPop=pop;
    if ~isempty(g_memory)        
        % sort the swarm in descending order according to the fitness        
%         [~,ipf]=sort(popFit,1,'descend');
%         newPop(ipf(1:numReplace),:)=replacePool;
        
        % sort the swarm in descending order
        if isempty(gmaxcons)
            maxcons=ones(1,size(popG,2));
        else
            maxcons=gmaxcons;
        end
        popG(popG<0)=0;
        cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
        [~,ipf]=sortrows([-popFit, -cons],[2, 1]);
        newPop(ipf(1:numReplace),:)=replacePool;
   
    end
    
elseif method == 1 || method == 2
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem_new(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    para=2;
    initSize=2*NP;
    num = initSize-(NP+numReplace);
    if num > 0
        [rndPop] = initialSwarm(num,bound,DIM,2);
    else
        rndPop=[];
        initSize=(NP+numReplace);
    end    
    newPop=[pop;replacePool;rndPop];
    popFit=zeros(initSize,1);
    popG=repmat(popG,para,1);
    for i=1:initSize        
        [popFit(i,1),popG(i,:),changeoccur] = evaluate(newPop(i,:),casedata);
    end
    
    % sort the swarm in descending order
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
    [~,ipf]=sortrows([popFit, cons],[2, 1]);

    newPop=newPop(ipf(1:NP),:);
    popFit=popFit(ipf(1:NP),:);
    popG=popG(ipf(1:NP),:);
elseif method == 0
    newPop=pop;
end




%%
statsafterchange();
end


clear all
load expSetup.mat;
psDE=10;
DEs=[DE,TDE,DEahcSPX, DEPSR,DESFLS,   jDE, OBDE,DEGL,SaDE, psDE];
 %        
DENames=...
   ['DE      ';
    'TDE     ';
    'DEahcSPX';
    'DEPSR   ';
    'DESFLS  ';
    'jDE     ';
    'OBDE    ';
    'DEGL    ';
    'SaDE    ';
    'psDE    '];

bestResults30=zeros(10,RUN);
times30=zeros(10,RUN);

bestResults57=zeros(10,RUN);
times57=zeros(10,RUN);

bestResults118=zeros(10,RUN);
times118=zeros(10,RUN);

fitness30=zeros(10,c30_nfe/50);
diverse30=zeros(10,c30_nfe/50);

fitness57=zeros(10,c57_nfe/50);
diverse57=zeros(10,c57_nfe/50);

fitness118=zeros(10,c118_nfe/50);
diverse118=zeros(10,c118_nfe/50);

% DE


for s=DEs
    for r=1:RUN
        dename=DENames(s,:);
        dename=dename(dename~=' ');
        filename=[dename,'_case30','_run',num2str(r),'_NP',num2str(NP)]    ;
        eval(['load ',filename,'.mat;']);
        bestResults30(s,r)=best;
        times30(s,r)=time;
        fitness30(s,:)=fitness30(s,:) + g_record(1:c30_nfe/50)'./RUN;
        diverse30(s,:)=diverse30(s,:) + g_diverse(1:c30_nfe/50)'./RUN;

        filename=[dename,'_case57','_run',num2str(r),'_NP',num2str(NP)]    ;
        eval(['load ',filename,'.mat;']);
        bestResults57(s,r)=best;
        times57(s,r)=time;
        fitness57(s,:)=fitness57(s,:) + g_record(1:c57_nfe/50)'./RUN;
        diverse57(s,:)=diverse57(s,:) + g_diverse(1:c57_nfe/50)'./RUN;

        filename=[dename,'_case118','_run',num2str(r),'_NP',num2str(NP)]    ;
        eval(['load ',filename,'.mat;']);
        bestResults118(s,r)=best;
        times118(s,r)=time;
        fitness118(s,:)=fitness118(s,:) + g_record(1:c118_nfe/50)'./RUN;
        diverse118(s,:)=diverse118(s,:) + g_diverse(1:c118_nfe/50)'./RUN;
    end
end
avg30=mean(bestResults30');
max30=max(bestResults30');
min30=min(bestResults30');
std30=std(bestResults30');
time30=(sum(times30,2)/RUN)';
save('result30.prn','avg30','max30','min30','std30','time30','-ASCII');

avg57=mean(bestResults57');
max57=max(bestResults57');
min57=min(bestResults57');
std57=std(bestResults57');
time57=(sum(times57,2)/RUN)';
save('result57.prn','avg57','max57','min57','std57','time57','-ASCII');

avg118=mean(bestResults118');
max118=max(bestResults118');
min118=min(bestResults118');
std118=std(bestResults118');
time118=(sum(times118,2)/RUN)';
save('result118.prn','avg118','max118','min118','std118','time118','-ASCII');

color=['-b',':c','-.g','--k','-m',':c','-.y','--b','-g','-.r'];
%color=['b.','c+','g*','ks','md','r^','yo','b>','r<'];
figure('color','white')
for uu=DEs
     plot(fitness30(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����50��');
ylabel('Ploss');
saveas(gcf,'FitIEEE30.jpg')

figure('color','white')
for uu=DEs
     plot(diverse30(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����50��');
ylabel('Diversity');
saveas(gcf,'DiverseIEEE30.jpg')

fitnessprint57=fitness57(:,1:2:end);
diverseprint57=diverse57(:,1:2:end);

figure('color','white')
for uu=DEs
     plot(fitnessprint57(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����100��');
ylabel('Ploss');
saveas(gcf,'FitIEEE57.jpg')

figure('color','white')
for uu=DEs
     plot(diverseprint57(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����100��');
ylabel('Diversity');
saveas(gcf,'DiverseIEEE57.jpg')



fitnessprint118=fitness118(:,1:3:end);
diverseprint118=diverse118(:,1:3:end);


figure('color','white')
for uu=DEs
     plot(fitnessprint118(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����200��');
ylabel('Ploss');
saveas(gcf,'FitIEEE118.jpg')

figure('color','white')
for uu=DEs
     plot(diverseprint118(uu,:),color(uu))
     hold on;
end
legend('DE','TDE','DEahcSPX','DEPSR','DESFLS','jDE','OBDE','DEGL','SaDE','psDE');
xlabel('nfe����200��');
ylabel('Diversity');
saveas(gcf,'DiverseIEEE118.jpg')
clear all
RUN=30;
CR=0.3;
F=0.7;
NP=40;

DE=1;
TDE=2;
DEahcSPX=3;
DEPSR=4;
DESFLS=5;
jDE=6;
OBDE=7;
DEGL=8;
SaDE=9;

c30_nfe=6000;
c57_nfe=12000;
c118_nfe=30000;

TDE_MutRate=0.05;
DEahcSPX_np=10;
DEahcSPX_ep=1;
DEPSR_Ns=4;
DESFLS_tau=0.03;
jDE_tau1=0.1;
jDE_tau2=0.1;
OBDE_jumprate=0.05;
DEGL_alpha=0.7;
DEGL_beta=0.7;
DEGL_k=8;

save('expSetup.mat');
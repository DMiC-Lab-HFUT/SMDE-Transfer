function draw_fig_14()
clear;
clc;
clear all;
folder_fig='Figures\';
if exist(folder_fig,'dir')==7
    mkdir(folder_fig);
end

maximum_error=5;
index=calculate_trackingError_fig_14(maximum_error);

probs={'dCase57', 'dCase118'};
case_renewablePower=1;
casedata= probs{1};
disp(casedata);
ideal_filename=['ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
load(ideal_filename, 'bestSolutionEachPeriod');
%�ֱ��ȡtracking error
maxNfe = 10* 5000;
for method = 0:5
    fileName=['Error_nfe_dCase57_method',num2str(method),'_run',num2str(index(method+1)),'.mat'];  
    eval(['load(fileName,''tracking_error_nfe_',num2str(method),''');']);
    eval(['load(fileName,''violation_',num2str(method),''');']);
end

x=2500:50:maxNfe;
h=figure(1);
plot(x,tracking_error_nfe_1(x,:),'k-',x,tracking_error_nfe_3(x,:),'r--');
axis([2500, maxNfe, 0, 14]);
set(gca, 'XTick', [2500,5000:5000:maxNfe]);%[2500:2500:maxNfe]
legend('SMDE-I','MEDE');

xlabel('Number of function evaluations');
ylabel('Best error');
str=[folder_fig,'\fig_14_',num2str(1),'.eps'];
saveas(h,str);

% hold on;
% h=figure(2);
% plot(x,tracking_error_nfe_1(x,:),'k-',x,tracking_error_nfe_4(x,:),'r-');
% 
% set(gca, 'XTick', [2500,5000:5000:maxNfe]);
% legend('SMEDE-I','interior-point');
% xlabel('Number of function evaluations');
% ylabel('Best error');
% str=[folder_fig,'\fig_14_',num2str(2),'.eps'];
% saveas(h,str);

end
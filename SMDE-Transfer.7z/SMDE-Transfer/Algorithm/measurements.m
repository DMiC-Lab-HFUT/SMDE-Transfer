function measurements()
folder=[];%'Results\';
% if exist(folder,'file')==0
%     disp('error!');
%     keyboard;
% end

prob=0.2;
prob_gen=0.01;
nstyle=1;
changehandler=6;
usearchive=2;
seeds=1:20;
gamma = 0.2;
numbusSet=[5];
numDynGen=2;
NP=50;
phi=1;
probs={'dCase57', 'dCase118'};
for method = 2
    for jj=2
        casedata= probs{jj};
        for numbus = numbusSet
            num=numel(seeds);
            trackingError_all=zeros(num,1);
            nIter_all=zeros(num,1);
            numChanges_all=zeros(num,1);
            numOfFeaGen_all=zeros(num,1);
            feasibleTime=0;
            num_satisfied_all=0;
            num_FEs = 0;
            bestPerformance=0;
            numFeaPeriods=0;
            for seed = seeds
                outname=[casedata,'_alg',num2str(method),'_bus',num2str(numbus),...
                    '_gen',num2str(numDynGen),'_tau',num2str(prob*100),'_NP',num2str(NP),...
                    '_phi',num2str(phi),'_cs',num2str(nstyle),...
                    '_ch',num2str(changehandler),'_ua',num2str(usearchive),'_run',num2str(seed),'.mat'];
                
                %
%                 folder1='idealResults_57\';
                outname1=['ideal_dCase118_alg1_bus5_gen2_tau20_NP50_phi1_cs1_ch6_ua2_run1.mat'];
               outfile=[folder,outname];
               outfile1=[outname1];
               load(outfile1, 'bestSolutionEachPeriod');
               optimalValues=bestSolutionEachPeriod;
                load(outfile, 'bestSolutionEachPeriod','output');
                
                
%                 load(outfile);
%                 trackingError_all(seed)=output.trackingError;
                nIter_all(seed)=output.nIter;
                numChanges_all(seed)=output.numChanges;
                numOfFeaGen_all(seed)=output.numOfFeaGen;
                feasibleTime=feasibleTime+output.feasiblePeriods;
                
                numChanges = size(bestSolutionEachPeriod, 1);
                num_satisfied=0;
                nfe_pre_change =0;
                for ii=1:numChanges
                    optimum = optimalValues(ii,2);
                    bestObtained = bestSolutionEachPeriod(ii, 2);
                    nfe_change = bestSolutionEachPeriod(ii, 1);
                    if(sum(bestSolutionEachPeriod(ii, 3:5)))==0
                        bestPerformance=bestPerformance+bestObtained;
                        numFeaPeriods=numFeaPeriods+1;
                        error=bestObtained-optimum;
                        if error >0
                            trackingError_all(seed)=trackingError_all(seed)+error;
                        end
%                         %% Tracking success ratio
%                         ratio = ((bestObtained - optimum)/optimum);
%                         is_satisfy= ratio < gamma;
%                         num_satisfied=num_satisfied+is_satisfy;
%                         
%                         %% Tracking speed
%                         nfe = 0;
%                         for loop = nfe_pre_change+1:nfe_change
%                             fit = fullrecord(loop,1);
%                             con = fullrecord(loop, 2:4);
%                             if (sum(con) ==0) && ((fit - optimum)/optimum) < gamma
%                                 nfe = loop - nfe_pre_change;
%                                 num_FEs = num_FEs + nfe;
%                                 break;
%                             end
%                         end
                        
                    end
                    nfe_pre_change = nfe_change;
                end
                
            end
%             %% Tracking success ratio
%             num_satisfied_all = num_satisfied_all + num_satisfied;
%             trackingSuccessRatio = num_satisfied_all/sum(numChanges_all);
%             %% Tracking speed
%             trackingSpeed = num_FEs/sum(numChanges_all);
            %% Feasible time ratio
            feasibleTimeRatio=feasibleTime/sum(numChanges_all);
            feasiblePeriodRatio= sum(numOfFeaGen_all)/sum(nIter_all);
            %% Tracking error
            trackingError = sum(trackingError_all)/(feasibleTime);
            bestPerformance=bestPerformance/numFeaPeriods;
            %% print
%             disp(['trackingSuccessRatio: ', num2str(trackingSuccessRatio)]);
            disp(['method: ',num2str(method)]);
            disp(['trackingError: ',num2str(trackingError)]);
%             disp(['trackingSpeed: ',num2str(trackingSpeed)]);
            disp(['FeaRatio_generation: ',num2str(feasiblePeriodRatio)]);
            disp(['FeaTimeRatio: ',num2str(feasibleTimeRatio)]);
            disp(['bestPerformance: ',num2str(bestPerformance)]);
            
            file=[folder,'finalResults_',casedata,'_nbus',num2str(numbus),'_sevPD',...
                num2str(prob),'_sevPG',num2str(prob_gen),'_gamma',num2str(gamma),'_run',num2str(seed),'.mat'];
%             save(file, 'trackingSuccessRatio', 'trackingError', 'trackingSpeed', 'feasiblePeriodRatio', ...
%                 'feasibleTimeRatio', 'numChanges_all','numOfFeaGen_all','num_satisfied_all');
            save(file);
        end
    end
end

end
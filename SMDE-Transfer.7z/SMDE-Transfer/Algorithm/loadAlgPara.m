function [MaxNfe,Sr,changehandler]=loadAlgPara(MaxNfe,ch,ifcalcideal,usearchive)
global g_algpara;

% NP=100;
% F=0.7;
% CR=0.9;
Sr=0.475;
changehandler=ch;%0: reevaluate
                 %1: reinitialize several individuals
                 %2: memory
                 %3  nothing
nretmemindv=5;
%%---------------------------------
% g_algpara.NP=NP;
g_algpara.MaxNfe=MaxNfe;
% g_algpara.CR=CR;
% g_algpara.F=F;
g_algpara.Sr=Sr;
g_algpara.changehandler=changehandler;
g_algpara.ifcalcideal=ifcalcideal;
g_algpara.nretmemindv=nretmemindv;
g_algpara.usearchive=usearchive;

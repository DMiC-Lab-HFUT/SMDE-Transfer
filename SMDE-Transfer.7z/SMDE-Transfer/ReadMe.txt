[Notice]
Developed by Chenyang Bu. Email address: chenyangbu@hfut.edu.cn

The codes were not developed professionally. 
The purpose of making the codes available is to allow other researchers to reproduce our reported results.

If you make use of these codes, please cite our publications below. 
1. Chenyang Bu, Wenjian Luo, Tao Zhu, Ruikang Yi and Bin Yang. A Species and Memory Enhanced Differential Evolution for Optimal Power Flow Under Double-Sided Uncertainties. IEEE Transactions on Sustainable Computing, accepted. 

In addition, the following publications are also encouraged to be cited.
1. Tao Zhu, Wenjian Luo, Chenyang Bu, Lihua Yue. Accelerate population-based stochastic search algorithms with memory for optima tracking on dynamic power systems. IEEE Transactions on Power Systems. vo. 31, no. 1, pp. 268-277.
2. Chenyang Bu, Wenjian Luo and Lihua Yue. Continuous Dynamic Constrained Optimization with an Ensemble of Locating and Tracking Feasible Regions Strategies. IEEE Transactions on Evolutionary Computation. vol. 21, no. 1, pp. 14-33, 2017.

[Compilation]
 We compiled this software on Windows.

System: Windows 10
CPU: Inter(R) Core(TM) i7-8700K CPU @ 3.70GHZ
RAM: 48.0 GB
Language: MATLAB R2018b

[Usage]
Please run the file 'setup.m' first.

function [pop] = initialSwarm(NP,bound,DIM,usearchive,Xini_PG)
% global g_caseconfig;
% global method;
global s2;
% global gmaxcons;

pop=rand(s2, NP,DIM);
pop=pop.*repmat((bound(:,2)-bound(:,1))',NP,1);
pop=pop+repmat(bound(:,1)',NP,1);


end
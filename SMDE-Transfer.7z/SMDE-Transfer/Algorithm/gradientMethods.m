function [output] = gradientMethods(casedata,num_DynBus,num_DynGen,...
    fileName,maxNumChanges,seed,algID,ChangeFrequency,case_Power)
%% global variables
global nfe;
global bestPerformance;
global feasiblePeriods;
global trackingError;
global is_DEBUG;
global s2;
global case_renewablePower;
global numChanges;
global frequency;
global numOfFeaGen;
global cgen;
global g_algpara;
global g_caseconfig;
global nIter;
global num_LS;
global g_conpara;
global gmaxcons;
global gbestfit;
global gbestcons;
global bestSolutionEachPeriod;
global optimalValues;
global gbest;
global numSpePerGen;
global single_run;
global niterEachPeriod;
%% ���������
% ��������������У��ֱ����ڲ�ͬ�ķ������Թ�ƽ�Ƚ�
[s1,s2,s3,s4,s5] = RandStream.create('mrg32k3a','NumStreams',5,'Seed',seed);
% ������������ӹ̶�
[s0] = RandStream.create('mrg32k3a','Seed',0);
RandStream.setGlobalStream(s0);
%% initialization
changestyle=1;%no use
changeprob=0.2;%no use
iscalcideal=1;%no use
prob_gen=1;%no use
[cbus, cgen]=setDynamicBus(num_DynBus, num_DynGen, casedata);
[Pmax, Pmin]=caseconfig(casedata,cbus,cgen,changeprob,changestyle,prob_gen);
[bound,DIM]=loadProPara(casedata,num_DynGen,Pmax, Pmin);
LB=bound(:,1)';
UB=bound(:,2)';
range=(bound(:,2)-bound(:,1))';
case_renewablePower=case_Power;
NP=50;
popFit=zeros(NP,1);
popG=zeros(NP,3);
%% parameters settings
is_DEBUG = 1;
method=algID;
trackingError=0;
numChanges=0;
feasiblePeriods=0;
bestPerformance=0;
nfe=0;%number of function evaluations
case_renewablePower=case_Power;
frequency=ChangeFrequency;
numOfFeaGen=0;
nIter=0;
num_LS=0;
g_algpara.algID=algID;
g_algpara.casedata=casedata;
maxNfe=maxNumChanges*ChangeFrequency;
statsafterchange();
tic;
while nfe < maxNfe
    g_caseconfig.flag=1;
    % Random initial positions      
    
    [pop] = initialSwarm(NP,bound,DIM,0);
    popFit=zeros(NP,1);
    popG=zeros(NP,3);
    for i=1:NP
        [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata,fileName);
    end
    
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    
    popG(popG<0)=0;
    
    cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([popFit, cons],[2, 1]);
    
    pop=pop(index(1:NP),:);
    popFit=popFit(index(1:NP),:);
    popG=popG(index(1:NP),:);
    
    x0=pop(1,:);
    [output_LS]=LocalSearch(casedata,fileName,x0,bound,method);
    numEval = mod(nfe, ChangeFrequency);
    numRemain = ChangeFrequency - numEval;
    
    if output_LS.has_change == true  || numRemain <= (DIM + NP)
        [pop] = initialSwarm(numRemain, bound, DIM, 0);
        for i=1:numRemain
            [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata,fileName);
        end
        %         disp(nfe);
    end
    
    %     has_change=true;
    %     numChanges=numChanges+1
    %     dynamic_bus(has_change);
end

time=toc;

folder='Results_LS\';

if exist(folder,'file')==0
    mkdir(folder);
end

trackingError=trackingError/feasiblePeriods;
output.trackingError=trackingError;
output.bestSolutionEachPeriod  = bestSolutionEachPeriod;
output.numChanges=numChanges;
output.feasiblePeriods=feasiblePeriods;
output.bestPerformance=bestPerformance;
output.time=time;
outfile=[folder,fileName,'.mat'];
save(outfile);
clear global
end


function [output_LS]=LocalSearch(casedata,fileName,x0,bound,method)
format long;
% RandStream.setDefaultStream(s);
global nfe;
global DELTA;
global numChanges;
global DELTA_1;
global has_change_LS;
global test;
global frequency;
global casedata_LS;
global fileName_LS;
global dimension;
global num_LS;
casedata_LS = casedata;
fileName_LS = fileName;

has_change_LS=false;
DELTA=1.0e-12;
DELTA_1=1.0e12;
num_LS=num_LS+1;
% disp(['numLS: ',num2str(num_LS),'; nfe:',num2str(nfe)]);
test=mod(nfe,frequency);
lb=bound(:,1)';
ub=bound(:,2)';
dimension=numel(lb);
maxNfe_LS=(numChanges+1)*frequency -nfe-1;
if method == 4
    options=optimset('Algorithm','interior-point','GradObj','off','GradConstr','off','TolCon',0,'OutputFcn', @outFun,'Display','off','TolFun',0.0,'MaxFunEvals',maxNfe_LS);
elseif method == 5
    options=optimset('Algorithm','sqp','GradObj','off','GradConstr','off','TolCon',0,'OutputFcn', @outFun,'Display','off','TolFun',0.0,'MaxFunEvals',maxNfe_LS);
end
[X,FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN]=fmincon(@myFun,x0,[],[],[],[],lb,ub,@myCon,options);

output_LS.XNew =X;
output_LS.fitness=FVAL;
output_LS.newNEval=nfe;
output_LS.sumVio=OUTPUT.constrviolation;
output_LS.has_change=has_change_LS;
% disp(['numLS: ',num2str(num_LS),'end']);
end
function [swarm, numSpe2] = twoStepNearestSeedsClustering(pop,popFit, popG, seeds)
% method:
%   two-step Nearest Seeds Clustering (NSC-2)
% input:
%   seeds - the set of seeds in previous generation
%   popFit -
%   popG -
%   seeds - the set of seeds identified in the previous generation
% output:
%   species - a vector indicating the species index of each individual, i.e.,
%   species(i) is the index of the species that the $i$-th individual belongs to
%   numSpe - the number of species



% [NP, DIM]=size(pop);
numSpe1=size(seeds,1);
swarm = [];

[~, species]=pdist2(seeds, pop, 'euclidean','Smallest', 1);

numSpe2=0;
seedsIndex=zeros(numSpe1, 1);
for i=1:numSpe1
    subSwarm=find(species==i);
    if ~isempty(subSwarm)
        numSpe2=numSpe2+1;
        if numSpe2 < i
            species(subSwarm)=numSpe2;% assign the acutal label to the species
        end
        [ID_best]=debbest(popFit(subSwarm),popG(subSwarm,:));
        seedsIndex(numSpe2)=subSwarm(ID_best);
    end
end

% for i=1:numSpe2
%     subSwarm=find(species==i);
%     swarm1(i).particles = subSwarm;
%     swarm1(i).size=numel(subSwarm);
%     swarm1(i).seedID=seedsIndex(i);
%     swarm1(i).seedLoc = pop(seedsIndex(i), :);
%     swarm1(i).mean = mean(pop(subSwarm,:), 1);
%     
% end
% swarm=swarm1;
seedsIndex = seedsIndex(1:numSpe2);
seeds = pop(seedsIndex, :);
% for i=1:numSpe2
%     seeds(i,:)=swarm1(i).mean;
% end

[~, species]=pdist2(seeds, pop, 'euclidean','Smallest', 1);
for i=1:numSpe2
    subSwarm=find(species==i);
    swarm(i).particles = subSwarm;
    swarm(i).size=numel(subSwarm);
    swarm(i).seedID=seedsIndex(i);
    swarm(i).seedLoc = pop(seedsIndex(i), :);
end

end
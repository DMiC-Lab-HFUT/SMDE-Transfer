% Table I - IV: SQP and Interior point method

%% Preprocessing
clear;
clear global;
folder='Results\';

currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\Algorithm']);
addpath([currentFolder,'\data']);
if exist(folder,'file')==0
    mkdir(folder);
end

flag_parallel_run = false;% true, false
flag_test = false; % true, false

%% Experimental settings
numChanges=10; % Total number of changes per run
methods=[4:5]; % To decide the set of compared algorithms
seeds=1:20; % the set of random seeds
% Note that if you want to change the settings of $num_cbus$ and $numDynGen$,
% the corresponding codes in the test problms should also be changed.
num_cbus =5; % the number of dynamic buses (to simulate the dynamics of demanded active power)
numDynGen=2; % the number of dynamic generator buses (to simulate the dynamics of renewable power generations)
probs={'dCase57', 'dCase118'};  % The set of test problems
numRuns=numel(seeds); % The total numbel of independent runs
changehandle=6;%not used
usearchive=2;%not used
numMemSize = 200;%not used
case_renewablePower=1:2;%1: ���ܷ��磻2��̫���ܷ���
fileName='Results\\LS_';
if flag_test == true % For DEBUG purpose
    seeds = 10;
    numRuns=numel(seeds);
    numChanges=10;
    methods=4;
end

%% Main loop
for frequency=[5000, 10000] % To decide the test problem (1: IEEE 57-bus; 2: IEEE 118-bus case )
    disp(' ');
    disp(['frequency:',num2str(frequency)]);
    if frequency == 5000
        casedata= probs{1};% For the IEEE 57-bus case
    elseif frequency == 10000
        casedata= probs{2};% For the IEEE 118-bus case
    end
    
    for case_renewablePower= 1:2 %1: ���ܷ���(Wind Power)  2��̫���ܷ��� (Solar Power)
        disp(['case_renewablePower:',num2str(case_renewablePower)]);
        
        for method=4:5  % Compared methods
            switch method
                case 4
                    note=['interior-point'];
                case 5
                    note=['SQP'];
            end
            
            disp(['method:',num2str(method)]);
            MaxNfe=numChanges*frequency; % Termination condition of each run
            
            % Intermediate variables for the measurements
            feasibleTime_all=zeros(numRuns,1);
            trackingError_all=zeros(numRuns,1);
            nIter_all=zeros(numRuns,1);
            numChanges_all=zeros(numRuns,1);
            numOfFeaGen_all=zeros(numRuns,1);
            feasibleTime=0;
            numFeaPeriods=0;
            trackingError_sum = 0;
            total_vio = 0;
            total_vio_all = zeros(numRuns,1);
            output_all = cell(numRuns,1);
            
            fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
                num2str(numDynGen),'_renewablePower',num2str(case_renewablePower)];
            
            %% Load optimal values
            disp(['case_renewablePower:',num2str(case_renewablePower)]);
            ideal_fileName=['data/Ideal_results/ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
            load(ideal_fileName, 'bestSolutionEachPeriod');
            optimalValues=bestSolutionEachPeriod;           

           
            %% Conduct $numRuns$ independent times
            if flag_parallel_run == true
                delete(gcp('nocreate'));
                try
                    parpool('local',numRuns);
                catch ce
                    parpool;
                    fail_p=gcp('nocreate');
                    fail_size=fail_p.NumWorkers;
                    display(ce.message);
                    display(strcat('�����size����ȷ�����õ�Ĭ������size=',num2str(fail_size)));
                end
                spmd(numRuns)
                    %% Run the gradient-based algorithms
                    fileName2=[fileName,'_run',num2str(labindex)];
                    [output_all]=gradientMethods(casedata,num_cbus,numDynGen,...
                        fileName2,numChanges,labindex,method,frequency,case_renewablePower);
                end
            else
                for seed=seeds
                    
                    %% Run the gradient-based algorithms
                    fileName2=[fileName,'_run',num2str(seed)];
                    [output]=gradientMethods(casedata,num_cbus,numDynGen,...
                        fileName2,numChanges,seed,method,frequency,case_renewablePower);
                    output_all{seed}=output;
                end
            end
            
            for seed=seeds
                %% The experimental results for the current run                
                if numRuns == 1 && flag_parallel_run == true
                    output=output_all;
                elseif numRuns > 1
                    output=output_all{seed};
                end
                
                numChanges_all(seed)=output.numChanges;
                feasibleTime_all(seed)=+output.feasiblePeriods;
                feasibleTime=feasibleTime+output.feasiblePeriods;
                
                %% Measurements
                for ii=1:numChanges
                    bestObtained = output.bestSolutionEachPeriod(ii, 2);
                    optimum = optimalValues(ii,2);
                    total_vio = total_vio+sum(output.bestSolutionEachPeriod(ii, 3:5));
                    total_vio_all(seed) = total_vio_all(seed) + sum(output.bestSolutionEachPeriod(ii, 3:5));
                    
                    if(sum(output.bestSolutionEachPeriod(ii, 3:5)))==0 % A feasible solution was found
                        numFeaPeriods=numFeaPeriods+1;
                        error=bestObtained-optimum;% The fitness error
                        if error > 0
                            trackingError_all(seed)=trackingError_all(seed)+error;
                            trackingError_sum=trackingError_sum + error;
                        end
                    end
                end
            end
            %% Feasible time ratio
            feasibleTimeRatio=feasibleTime/sum(numChanges_all);
            trackingError = trackingError_sum/feasibleTime;
            
            disp([num2str(feasibleTimeRatio),' ',num2str(trackingError), ' ', num2str(mean(total_vio_all)/numChanges),' ', num2str(std(total_vio_all))]);
            
            folder1=[folder,'\Measurements\'];
            if exist(folder1,'file')==0
                mkdir(folder1);
            end
            save([folder1,fileName,'.mat'],'trackingError','numChanges_all','feasibleTime','method','feasibleTimeRatio','note','output_all','trackingError_all');
            delete(gcp('nocreate'));
            
        end
        
    end
end


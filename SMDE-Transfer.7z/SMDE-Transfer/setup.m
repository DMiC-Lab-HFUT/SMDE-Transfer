function setup()
clear;
clear global;
distcomp.feature( 'LocalUseMpiexec', false );
currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\data\Ideal_results']);
addpath([currentFolder,'\data']);
addpath([currentFolder,'\Algorithm']);
addpath([currentFolder,'\Measurements']);
addpath([currentFolder,'\data\init_memory']);
folder='Results\';
if exist(folder,'file')==0
    mkdir(folder);
end
folder='Results_LS\';
if exist(folder,'file')==0
    mkdir(folder);
end
addpath([currentFolder,'\Results']);
addpath([currentFolder,'\Results2']);
addpath([currentFolder,'\Results\Measurements']);
addpath([currentFolder,'\Results_LS']);
folder_fig='Figures\';
if exist(folder_fig,'dir')==7
    mkdir(folder_fig);
end
end
function [Pmax, Pmin,Xini]=caseconfig(casename,cbus,cgen,prob,style,prob_gen)
global g_caseconfig;
g_caseconfig=struct('casename',{[]},'flag',{[]},'indics',{[]},'prob',{[]},...
   'sev',{[]},'loads',{[]},'baseloads',{[]},'style',{},'record',{},...
    'indics_gen',{[]},'prob_gen',{[]},'formerPG',{[]},'PG',{[]},'PG_all',{[]}); %modified by Chenyang Bu
   
[~, bus, gen] = loadcase(casename);
numDynGen=numel(cbus);

if(strcmpi(casename,'dCase118'))
    numGen=54-numDynGen;
    g_caseconfig(1).numvar=75+numGen-1;
elseif(strcmpi(casename,'dCase30'))   
    g_caseconfig(1).numvar=11;
elseif(strcmpi(casename,'dCase57'))
     numGen=7-numDynGen;
    g_caseconfig(1).numvar=26+numGen-1;
else
    keyboard;
end

if(style==1)
    g_caseconfig(1).style=@changestyle_stochastic;
elseif(style==2)
    keyboard;
    %...
%     idealstats=getAlgLog(record,'idealstats');
%     g_caseconfig(1).record=idealstats(:,[1,size(idealstats,2)-numel(cbus)+1:size(idealstats,2)]);
%     g_caseconfig.style=@changestyle_followrecord;
end
if nargin==1 %&& strcmpi(casename,'case30')
    cbus=[7;19;21;24;30];  % indics of the changing bus
end

Pmax=gen(:, 9);
Pmin=gen(:,10);
Xini=gen(:,2);
Pmax([1;cgen],:)=[];
Pmax=Pmax';
Pmin([1;cgen],:)=[];
Pmin=Pmin';
Xini([1;cgen],:)=[];
g_caseconfig.indics=cbus;
g_caseconfig.casename=casename;
g_caseconfig.flag=0; % changeFlag
g_caseconfig.prob=prob*ones(size(cbus)); % probabilities to change
g_caseconfig.sev=0.2*ones(size(cbus)); % change severities;
g_caseconfig.loads=bus(cbus,3);%loads

g_caseconfig.formerloads=bus(cbus,3);
g_caseconfig.baseloads=bus(cbus,3); % bus;
g_caseconfig.nstyle=style;

g_caseconfig.indics_gen=cgen;
g_caseconfig.PG=gen(cgen, 2)/0.8;
g_caseconfig.prob_gen=prob_gen*ones(size(g_caseconfig.indics_gen));
g_caseconfig.formerPG=g_caseconfig.PG;


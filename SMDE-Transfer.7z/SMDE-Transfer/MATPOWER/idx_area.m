function [AREA_I, PRICE_REF_BUS] = idx_area
%IDX_AREA   Defines constants for named column indices to areas matrix.
%   [AREA_I, PRICE_REF_BUS] = idx_area
%
%   The index, name and meaning of each column of the areas matrix is given
%   below:
% 
%   columns 1-2
%    1  AREA_I       	area number
%    2  PRICE_REF_BUS	price reference bus for this area

%   MATPOWER
%   $Id: idx_area.m,v 1.6 2004/12/15 22:46:26 ray Exp $
%   by Ray Zimmerman, PSERC Cornell
%   Copyright (c) 1996-2004 by Power System Engineering Research Center (PSERC)
%   See http://www.pserc.cornell.edu/matpower/ for more info.

%% define the indices
AREA_I          = 1;    %% area number
PRICE_REF_BUS   = 2;    %% price reference bus for this area

return;

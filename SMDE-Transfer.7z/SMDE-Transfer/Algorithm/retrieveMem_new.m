function memindv=retrieveMem_new(loads, PG, value)
% simliar retrieval scheme

global g_memory;% structure: <loads, PG, variables, fitness, cons>
global g_caseconfig;
global memory;
global method;
memindv=[];

if size(loads, 1) > 1
    loads=loads';
end
if size(PG, 1) > 1
    PG=PG';
end
%% 1. based on g_memory
if isempty(g_memory)
    return;
end

index_variables=(numel(g_caseconfig.indics)+numel(g_caseconfig.indics_gen)+1):(size(g_memory,2)-4);

dif=g_memory(:,1:numel([loads, PG]))-repmat([loads, PG],size(g_memory,1),1);
means=mean(g_memory(:,1:numel([loads, PG])), 1);%modified by Chenyang Bu
normdif=abs(dif)./repmat(means,size(g_memory,1),1);
dis=sum(normdif,2);
radius=value.radius;
tao_1=value.nfe;
[~,index]=sort(dis);
index_simliar = dis<radius*numel([loads, PG]);
numIndSimilar=sum(index_simliar);
if numIndSimilar <= tao_1 && numIndSimilar > 0
    memindv = g_memory(index(index_simliar), index_variables);
else
    % P(n) = alpha * n + beta
    alpha=-2*tao_1/(numIndSimilar*(numIndSimilar+1));
    beta=2*tao_1/(numIndSimilar+1);
    % Assign the selection probabilities for these memory individuals,
    % i.e., P(0), P(1), ..., P(N-1)
    % The best one is ranked 0, and the next one is ranked 1, and so on
    % P(n) has the following properties:
    % 1) P(n) > P(n+1) > 0
    % 2) sum(P(n)) = tao_1
    probs=alpha*(0:numIndSimilar-1)+beta;%corrected by Chenyang Bu
    % the index of selected individuals
    selected=SUS(probs,tao_1);
    % the selected memory individuals
    memindv=g_memory(index(selected),index_variables);
end

if method ~= 3 % not MEDE (i.e., SMEDE or SMEDE-II)
    %% 2. based on local memory
    if isempty(memory)
        return;
    end
    num = numel(memory);
    preEnviroments =zeros(num,numel(loads)+numel(PG));
    for i=1:num
        preEnviroments(i,:) = [memory(i).loads',memory(i).PG'];
    end

%     preEnviroments = [memory.loads', memory.PG];
    disToMemory=pdist2(preEnviroments,[loads,PG]);
    [~, index]=min(disToMemory);
    memindv=[memindv; memory(index).localMemory];
    
end
end
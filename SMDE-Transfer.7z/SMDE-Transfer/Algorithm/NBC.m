function [swarm, numSpe]= NBC(distanceMatrix, RealIndex,phi)
% variables:
% nbc - the first column is the individual index; the second column is the
% index of its nearest neighbor; the third column is the distance to its
% nearest neighbor 
% global pop;
% global seeds;
global nbc_para;

[NP, ~]=size(distanceMatrix);
nbc=zeros(NP,3);
nbc(1:NP,1)=1:NP;
nbc(1,2)=-1;
nbc(1,3)=0;
n_followers=zeros(NP,1);
flag=false(NP,1);
for i=2:NP
    [dis,index]=min(distanceMatrix(i,1:i-1));
    nbc(i,2)=index;
    nbc(i,3)=dis;
end
meandis = phi*mean(nbc(2:NP,3));
for i=1:NP
    n_followers(i)=sum((nbc(:,2)==i));
    if nbc(i,3)>meandis && n_followers(i) >= nbc_para
        flag(i)=true;
    end
end

nbc(flag, 2)=-1;
nbc(flag, 3)=0;
seedsIndex = nbc(nbc(:,2)==-1,1);

numSpe=numel(seedsIndex);
swarm=[];
species=zeros(NP,1);
% identify the species number for each individual
for i=1:NP
    index=nbc(i,2);
    tmpIndex=index;
    while index~=-1
        tmpIndex=index;
        index=nbc(index,2);
    end
    if tmpIndex==-1
        species(i)=i;
    else
        species(i)=tmpIndex;
    end
end

for i=1:numSpe
    ID_seed=seedsIndex(i);
    sub_swarm = find(species==ID_seed);    
    swarm(i).particles=RealIndex(sub_swarm);
    swarm(i).seedID=RealIndex(ID_seed);
    swarm(i).size=numel(sub_swarm);
    swarm(i).rank = seedsIndex(i);
end

end


function  save2mem(loads, PG, pop, popFit, popG, swarm)
global g_memory;
global gbest;
global gbestfit;
global gbestcons;
global memorynow;
global numChanges;
global g_caseconfig;
global method;

numMemElements=numel(memorynow);

if method == 1  || method == 2
    flag = sum(gbestcons)<=1e-10;
else
    flag = 1;
end
if flag%sum(gbestcons)<=1e-10
    numMemElements=numMemElements+1;
    memorynow(numMemElements).bestLoc =gbest;
    memorynow(numMemElements).bestFit =gbestfit;
    memorynow(numMemElements).bestCon =gbestcons;
    numSpe=numel(swarm);
    preSeedsIndex=zeros(numSpe,1);
    for i = 1:numSpe
        preSeedsIndex(i) = swarm(i).seedID;
    end
    index=sum(popG(preSeedsIndex,:), 2) <= 1e-10;
    index=preSeedsIndex(index);
    %��õĽ�+���е�����
    memorynow(numMemElements).localMemory =[gbest; pop(index,:)];
    memorynow(numMemElements).LMFit =[gbestfit; popFit(index,:)];
    memorynow(numMemElements).LMCon =[gbestcons; popG(index,:)];
    memorynow(numMemElements).LMsize=size( memorynow(numMemElements).localMemory,1);%��¼һ�´�С
    %ʣ�µĿ��и������
    %�����ΪmemPop
    index2=sum(popG(:,:), 2) <= 1e-10;
    index2(index)=0;
    memorynow(numMemElements).memPop=pop(index2,:);
    memorynow(numMemElements).memPopFit=popFit(index2,:);
    memorynow(numMemElements).memPopG=popG(index2,:);
    memorynow(numMemElements).memsize=size( memorynow(numMemElements).memPop,1);%��¼һ�´�С
    %������Ⱥ����ʣ�µĸ���
    index3=sum(popG(:,:), 2) > 1e-10;
    memorynow(numMemElements).pop=pop(index3,:);
    memorynow(numMemElements).popFit=popFit(index3,:);
    memorynow(numMemElements).popG=popG(index3,:);
    %��������
    memorynow(numMemElements).PG=PG';
    memorynow(numMemElements).indics = g_caseconfig.indics;
    memorynow(numMemElements).indics_gen = g_caseconfig.indics_gen;
    memorynow(numMemElements).sev = g_caseconfig.sev;
    memorynow(numMemElements).prob_gen = g_caseconfig.prob_gen;
    memorynow(numMemElements).loads=loads';
    memorynow(numMemElements).numChanges=numChanges;
    memorynow(numMemElements).time=0;%not used
    memorynow(numMemElements).numLM=numel(index)+1;
end
if isempty(g_memory)
    g_memory(1,:)=[loads, PG, gbest, gbestfit, gbestcons];
    return;
end
dimloads=numel(loads);
dimvar=numel(gbest);
dimPG=numel(PG);
try
    disToMemory=pdist2(g_memory(:,1:dimloads+dimPG),[loads,PG]);
catch
    keyboard;
end
match= find(disToMemory<1e-5);
index_fitness = dimloads+dimPG+dimvar+1;
index_vio = index_fitness+1:index_fitness+3;
num = size(g_memory,1);
if ~isempty(match)
    ibest=debbest(g_memory(match,index_fitness),g_memory(match,index_vio));
    best=g_memory(match(ibest),:);
    g_memory(match,:)=[];
    if debbetter(gbestfit,gbestcons,best(index_fitness),best(index_vio))
        g_memory(num+1,:)=[loads,PG,gbest,gbestfit,gbestcons];
    else
        g_memory(num+1,:)=best;
    end
else
    g_memory(num+1,:)=[loads, PG, gbest, gbestfit, gbestcons];
end
end
function statsafterchange()
global gmaxcons;
global gbestfit;
global gbestcons;
global preSpeNum;
global numUnchanged_SpeNum;
global factor;
global step;
%% reinitialize stats parameters
if ~isempty(gbestfit)
    factor=1.0-step;
    preSpeNum=-1;
    numUnchanged_SpeNum=0;
    gbestfit=inf*ones(size(gbestfit));
    gbestcons=inf*ones(size(gbestcons));
    gmaxcons=zeros(size(gmaxcons))+0.001;
end
end
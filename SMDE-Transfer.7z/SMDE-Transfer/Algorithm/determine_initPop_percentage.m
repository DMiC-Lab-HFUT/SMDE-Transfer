function [numToReplaced, MemIdSet, localMemory] = determine_initPop_percentage(mu_sorted,mu_max, NP)
%% The following is to determine the percentage of memory
...and random solutions in the new population based on the
...fuzzy similarity.
    
global ratioRnd_min;
global memory;
global r_thre;
r_thre=0.6;
ratioRnd_min=0.2;

MemIdSet_index = mu_sorted.values >= r_thre;
ID = mu_max.id;
localMemory = memory(ID).localMemory;
numToReplaced = numel(MemIdSet_index) + memory(ID).numLM;
num_envs = 1:numel(memory);
MemIdSet = num_envs(MemIdSet_index);

N_max_replaced = floor(max(ceil(NP*mu_max.value), ceil(NP*(1-ratioRnd_min))));

numToReplaced = min(numToReplaced, N_max_replaced);

end
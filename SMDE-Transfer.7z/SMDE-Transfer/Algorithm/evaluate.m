function [fit,conv,changeoccur]=evaluate(v,casedata,fileName)
global trackingError;
global numChanges;
global gbestfit;
global gbestcons;
global bestSolutionEachPeriodx;
global g_caseconfig;
global feasiblePeriods;
global nIter;
global nfe;
global optimalValues;
global gbest;
global bestPerformance;
global numSpePerGen;
global single_run;
global niterEachPeriod;
if nargin < 3
    fileName='tmp.txt';
end
if isempty(bestPerformance)
    bestPerformance=0;
end
if isempty(niterEachPeriod)
    niterEachPeriod=zeros(10);
end
%% return the fitness and the value of constraints violation
if (strcmpi(casedata,'case30') || strcmpi(casedata,'dcase30'))
        [fit,conv] = rpflow30(v,casedata);
elseif(strcmpi(casedata,'case57') || strcmpi(casedata,'dcase57'))
        [fit,conv] = rpflow57(v,casedata);
elseif(strcmpi(casedata,'case118') || strcmpi(casedata,'dcase118'));
        [fit,conv] = rpflow118(v,'dCase118');
else
    disp('wrong casedata');
    keyboard;
end

update_stats(v,fit,conv);

changeoccur=dynamic_bus(casedata);
if changeoccur
    %numChanges=numChanges+1;
%     disp(numChanges);
    niterEachPeriod(numChanges)=nIter;%��¼�ı�Ĵ���
    if sum(gbestcons)==0%����ǿ��н�
        feasiblePeriods = feasiblePeriods + 1;%�ҵ����н�Ĵ�����1
        if ~isempty(optimalValues)
            error=gbestfit-optimalValues(numChanges, end-3);
            if error < 0
                error =0;
            end
            trackingError=trackingError+error;%��������
        end
        bestPerformance=bestPerformance+gbestfit;
    end
    
    num=numel([g_caseconfig.formerloads', g_caseconfig.formerPG',gbest]);
    bestSolutionEachPeriodx(numChanges, 1:1+1+3+num)=[nfe,  gbestfit, gbestcons, g_caseconfig.formerloads', g_caseconfig.formerPG', gbest];
    fit=inf;
    conv=[inf,inf,inf];
    
    
%     folder='tmpResults\';
%     if exist(folder,'file')==0
%         mkdir(folder);
%     end
%     save([folder,fileName,'.mat']);
%     return;
end

end

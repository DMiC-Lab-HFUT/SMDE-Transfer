function get_Tables()
%% Tables I-IV
clear;
clear global;
clc;
currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\Algorithm']);
addpath([currentFolder,'\Measurements']);
addpath([currentFolder,'\Results\Measurements']);
addpath([currentFolder,'\Results']);
addpath([currentFolder,'\Results_LS']);
folder_fig='Figures\';
if exist(folder_fig,'dir')==7
    mkdir(folder_fig);
end
numChanges=10; % Total number of changes per run
methods=[1,3,6]; % To decide the set of compared algorithms
seeds=1:20; % the set of random seeds
% Note that if you want to change the settings of $num_cbus$ and $numDynGen$,
% the corresponding codes in the test problms should also be changed.
num_cbus =5; % the number of dynamic buses (to simulate the dynamics of demanded active power)
numDynGen=2; % the number of dynamic generator buses (to simulate the dynamics of renewable power generations)
probs={'dCase57', 'dCase118'};  % The set of test problems
numRuns=numel(seeds); % The total numbel of independent runs
changehandle=6;%not used
usearchive=2;%not used
numMemSize = 200;%not used

%% Parameter settings
phi=1.0; % The clustering parameter of NBC
DE_F_weight=0.85; % the scale factor F of DE
DE_CR=0.9; % crossover rate CR
NP=50; % the population size NP
threshold_value=7; %the parameter $gen_threshold$
nbc_parameter=2; %The parameter ��of the ��-NBC
DE_strategy=2; %  The DE mutation strategy
folder='';

num=1;
num_algs = 7;
feasibleTimeRatio_all=zeros(num_algs,num);
tracking_error_all=zeros(num_algs,num);
mean_total_vio=zeros(num_algs,num);
std_total_vio=zeros(num_algs,num);
output_all = cell(20,1);

loop = 0;
for case_renewablePower=1:2
    for i=1:2 % To decide the test problem (1: IEEE 57-bus; 2: IEEE 118-bus case )
        casedata = probs{i}; % the test problem
        loop = loop+1;
        
        for method = methods
            if 1%method <=3
                fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
                    num2str(numDynGen),'_NP',num2str(NP),'_phi',num2str(phi*10),...
                    '_F',num2str(DE_F_weight),'_threshold',num2str(threshold_value),'_CR',num2str(DE_CR),'_nbc',num2str(nbc_parameter),'_Power',num2str(case_renewablePower),'_DE',num2str(DE_strategy)];
            else
                fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
                    num2str(numDynGen),'_renewablePower',num2str(case_renewablePower)];
            end
            
            outfile=[folder,fileName,'.mat'];
            %             load(outfile);
            load(outfile, 'feasibleTimeRatio','trackingError');
            
            feasibleTimeRatio_all(method+1,loop)=feasibleTimeRatio;
            tracking_error_all(method+1,loop)=trackingError;
            
              %% Load optimal values
%             disp(['case_renewablePower:',num2str(case_renewablePower)]);
            ideal_fileName=['data/Ideal_results/ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
            load(ideal_fileName, 'bestSolutionEachPeriod');
            optimalValues=bestSolutionEachPeriod;           
           
            % Intermediate variables for the measurements
            feasibleTime_all=zeros(numRuns,1);
            trackingError_all=zeros(numRuns,1);
            nIter_all=zeros(numRuns,1);
            numChanges_all=zeros(numRuns,1);
            numOfFeaGen_all=zeros(numRuns,1);
            feasibleTime=0;
            numFeaPeriods=0;
            trackingError_sum = 0;
            total_vio = 0;
            total_vio_all = zeros(numRuns,1);
            output_all = cell(numRuns,1);
            for seed = seeds
                fileName2=[fileName,'_run',num2str(seed),'.mat'];
                load(fileName2,'output');
                output_all{seed}=output;
            end
            for seed=seeds
                %% The experimental results for the current run
                output=output_all{seed};
                
%                 nIter_all(seed)=output.nIter;
                numChanges_all(seed)=output.numChanges;
%                 numOfFeaGen_all(seed)=output.numOfFeaGen;
                feasibleTime_all(seed)=+output.feasiblePeriods;
                feasibleTime=feasibleTime+output.feasiblePeriods;
                
                %% Measurements
                for ii=1:numChanges
                    bestObtained = output.bestSolutionEachPeriod(ii, 2);
                    optimum = optimalValues(ii,2);
                    total_vio = total_vio+sum(output.bestSolutionEachPeriod(ii, 3:5));
                    total_vio_all(seed) = total_vio_all(seed) + sum(output.bestSolutionEachPeriod(ii, 3:5));
                    
                    if(sum(output.bestSolutionEachPeriod(ii, 3:5)))==0 % A feasible solution was found
                        numFeaPeriods=numFeaPeriods+1;
                        error=bestObtained-optimum;% The fitness error
                        if error > 0
                            trackingError_all(seed)=trackingError_all(seed)+error;
                            trackingError_sum=trackingError_sum + error;
                        end
                    end
                end
            end
            %% Feasible time ratio
            feasibleTimeRatio=feasibleTime/sum(numChanges_all);
            %% Tracking error
            %             trackingError_sorted = (trackingError_all);
            %             for ii =1:numChanges
            %                 trackingError_sorted =trackingError_sorted/feasibleTime_all(ii);
            %             end
            trackingError = trackingError_sum/feasibleTime;
            mean_total_vio(method+1,loop) = mean(total_vio_all)/numChanges;
            std_total_vio(method+1,loop) = std(total_vio_all);
            
        end
        
    end
end
loop = 0;
for case_renewablePower=1:2
    for i=1:2 % To decide the test problem (1: IEEE 57-bus; 2: IEEE 118-bus case )
        disp('  ');
        disp([' case_renewablePower ',num2str(case_renewablePower), 'problem  ', num2str(i)]);
        loop = loop + 1;
        casedata = probs{i}; % the test problem
        for method=[1,3,6]
            %             for
%             disp([num2str(feasibleTimeRatio_all(method+1,loop)),' ',num2str(tracking_error_all(method+1,loop)),' ',num2str(mean_total_vio(method+1,loop)),'$\pm$',num2str( std_total_vio(method+1,loop))]);
            fprintf('%1.3f %1.3f %1.3f$\\pm$%1.3f\n',feasibleTimeRatio_all(method+1,loop),tracking_error_all(method+1,loop),mean_total_vio(method+1,loop),std_total_vio(method+1,loop));%             end
        end
    end
    
    
end
end
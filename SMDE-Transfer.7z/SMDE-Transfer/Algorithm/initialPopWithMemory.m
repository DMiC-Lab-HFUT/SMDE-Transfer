function [newPop,newPopFit, newPopG] = initialPopWithMemory(NP,bound,DIM,casedata)
global g_caseconfig;
global s2;
global gmaxcons;
global memory;
global method;


if method == 3
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    %% similar retrieval scheme
    memSimilar=retrieveMem(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% mean-based immigrants scheme
    numImmigrants = 10;
    imPop=memImmigrants(numImmigrants, bound);
    
    %% replace strategy
    numSimilarMem = size(memSimilar, 1);
    numImmigrants=size(imPop,1);
    numReplace = numSimilarMem + numImmigrants;
    
    numRandom = NP - numReplace;
    pop_rnd=rand(s2, numRandom,DIM);
    pop_rnd=pop_rnd.*repmat((bound(:,2)-bound(:,1))',numRandom,1);
    pop_rnd=pop_rnd+repmat(bound(:,1)',numRandom,1);
    newPop=[memSimilar; imPop;pop_rnd];
    
    newPopFit=zeros(NP, 1);
    newPopG=zeros(NP,3);

 %����������ǰ��Ⱥ
    for i=1:NP
        [newPopFit(i,1),newPopG(i,:)] = evaluate(newPop(i,:),casedata);
    end 
    
    %��������
    newPopG(newPopG<0)=0;
    if isempty(gmaxcons)
        maxcons=ones(1,size(newPopG,2));
    else
        maxcons=gmaxcons;
    end
    cons=sum(newPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([newPopFit, cons],[2, 1]);
    
    newPop=newPop(index(1:NP),:);
    newPopFit=newPopFit(index(1:NP),:);
    newPopG=newPopG(index(1:NP),:);
elseif method == 1 || method == 2
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem_new(g_caseconfig.loads',g_caseconfig.PG', value);   
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    para=2;
    initSize=2*NP;
    num = initSize - numReplace;
    if num > 0
        [rndPop] = initialSwarm(num,bound,DIM,2);
    else
        rndPop=[];
        initSize = numReplace;
    end    
    newPop=[replacePool;rndPop];
    popFit=zeros(initSize,1);
    popG = zeros(initSize, 3);
    for i=1:initSize        
        [popFit(i,1),popG(i,:),changeoccur] = evaluate(newPop(i,:),casedata);
    end
    
    % sort the swarm in descending order
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
    [~,ipf]=sortrows([popFit, cons],[2, 1]);

    newPop=newPop(ipf(1:NP),:);
    newPopFit=popFit(ipf(1:NP),:);
    newPopG=popG(ipf(1:NP),:);
elseif method >=6
    %% TODO
    flag_init = true;
    [simIndex,mu] = fuzzy_similarity(g_caseconfig.loads',g_caseconfig.PG', flag_init);
   [numToReplaced, MemIdSet_index, localMemory]  = determine_initPop_percentage(simIndex,mu,NP);    
       
    initSize = 2*NP;
    pop=rand(s2, initSize, DIM);
    pop=pop.*repmat((bound(:,2)-bound(:,1))',initSize,1);
    pop=pop+repmat(bound(:,1)',initSize,1);
    
    popFit=zeros(initSize,1);
    
    popG=zeros(initSize,3);
    
    %����������ǰ��Ⱥ
    for i=1:initSize
        [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata);
    end
    
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
    [~,index]=sortrows([popFit, cons],[2, 1]);
    
    pop=pop(index(1:initSize),:);
    popFit=popFit(index(1:initSize),:);
    popG=popG(index(1:initSize),:);
    
    %% replace strategy
    memPop=zeros(numToReplaced,DIM);
    memPopG = zeros(numToReplaced,3);
    memPopFit = zeros(numToReplaced,1);
    num1=numel(MemIdSet_index) ;
    num=min(num1, numToReplaced);
    for i=1:num
        memPop(i,:)=memory(MemIdSet_index(i)).bestLoc;
    end
    
    
    if num < numToReplaced
        memPop(num+1:end,:)=localMemory(1:(numToReplaced-num),:);
    end
    %����������ǰ��Ⱥ
    for i=1:numToReplaced
        [memPopFit(i,1),memPopG(i,:)] = evaluate(memPop(i,:),casedata);
    end
    
    numRnd = NP - numToReplaced;
    newPop =[memPop; pop(index(1:numRnd),:)];
    newPopFit=[memPopFit; popFit(index(1:numRnd),:)];
    newPopG=[memPopG; popG(index(1:numRnd),:)];
    
    
    %��������
    newPopG(newPopG<0)=0;
    cons=sum(newPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([newPopFit, cons],[2, 1]);
    
    newPop=newPop(index(1:NP),:);
    newPopFit=newPopFit(index(1:NP),:);
    newPopG=newPopG(index(1:NP),:);

end

end
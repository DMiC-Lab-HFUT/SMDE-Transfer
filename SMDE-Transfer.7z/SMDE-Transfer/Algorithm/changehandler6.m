function [newPop,newPopFit,newPopG,changeoccur]=changehandler6(pop,popFit,popG,bound,swarm,casedata)
global g_caseconfig;
global g_memory;
global gmaxcons;
global method;
global phi;
global memory;
global n_min;
global s2;
phi=1;
n_min = 3;%����
changeoccur=0;
[NP, DIM]=size(pop);
[~, n_con] = size(popG);
%% Update the memory sets todo:
save2mem(g_caseconfig.formerloads', g_caseconfig.PG', pop, popFit, popG,swarm);

if method == 3
    %% similar retrieval scheme
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% mean-based immigrants scheme
    numImmigrants = 10;
    imPop=memImmigrants(numImmigrants, bound);
    replacePool=[replacePool;imPop];
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    newPop=pop;
    if ~isempty(g_memory)
        % sort the swarm in descending order according to the fitness
        %         [~,ipf]=sort(popFit,1,'descend');
        %         newPop(ipf(1:numReplace),:)=replacePool;
        
        % sort the swarm in descending order
        if isempty(gmaxcons)
            maxcons=ones(1,size(popG,2));
        else
            maxcons=gmaxcons;
        end
        popG(popG<0)=0;
        cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
        [~,ipf]=sortrows([-popFit, -cons],[2, 1]);
        newPop(ipf(1:numReplace),:)=replacePool;
        
    end
    
elseif method == 0
    newPop=pop;
    
elseif method == 1 || method == 2
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem_new(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    para=2;
    initSize=2*NP;
    num = initSize-(NP+numReplace);
    if num > 0
        [rndPop] = initialSwarm(num,bound,DIM,2);
    else
        rndPop=[];
        initSize=(NP+numReplace);
    end
    newPop=[pop;replacePool;rndPop];
    popFit=zeros(initSize,1);
    popG=repmat(popG,para,1);
    for i=1:initSize
        [popFit(i,1),popG(i,:),changeoccur] = evaluate(newPop(i,:),casedata);
    end
    
    % sort the swarm in descending order
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
    [~,ipf]=sortrows([popFit, cons],[2, 1]);
    
    newPop=newPop(ipf(1:NP),:);
    newPopFit=popFit(ipf(1:NP),:);
    newPopG=popG(ipf(1:NP),:);

elseif method >= 6
    [mu_sorted, mu_max, mu_last_env] = fuzzy_similarity(g_caseconfig.loads',g_caseconfig.PG');
    [N_pre, N_rnd, N_mem, N_replaced, MemIdSet] = determine_pop_percentage(mu_sorted, mu_max, mu_last_env, NP);
    
    %����������ǰ��Ⱥ
    for i=1:NP
        [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata);
    end
    
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([popFit, cons],[2, 1]);
    
    pop=pop(index(1:NP),:);
    popFit=popFit(index(1:NP),:);
    popG=popG(index(1:NP),:);
    
    vio = sum(popG,2);
    
    %% replace strategy
    newPop = pop;
    newPopG = popG;
    newPopFit = popFit;
    
    
    %% ע����伯�еĽ�
    memPop = zeros(N_mem, DIM);
    num_MemPop = 0;
    if isempty(MemIdSet)
        memPop(1,:)=memory(mu_max.id).localMemory(1,:);
        num_MemPop=num_MemPop+1;
    else
        for i = MemIdSet
            id = mu_sorted.id(i);
            num=min(memory(id).numLM, ceil(N_mem/numel(MemIdSet)));
            num = min(num, N_mem-num_MemPop);
            memPop(num_MemPop+1:num_MemPop+num,:)=memory(id).localMemory(1:num,:);
            num_MemPop=num_MemPop+num;
        end
    end
    
    if num_MemPop < N_mem
        N_rnd = (N_replaced - N_mem);
    end
    
    for i=1:N_mem
        [memPopFit(i,1),memPopG(i,:)] = evaluate(memPop(i,:),casedata);
    end
    
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    memPopG(memPopG<0)=0;
    cons=sum(memPopG./repmat(maxcons,N_mem,1),2)./sum(1./maxcons);
    
    
    newPop(1:N_mem, :)=memPop;
    newPopFit(1:N_mem,:)=memPopFit;
    newPopG(1:N_mem,:)=memPopG;
    
    %% ע�������
    rndPopFit=zeros(NP,1);
    rndPopG=popG;
    [rndPop] = initialSwarm(NP,bound,DIM,2);
    % ������Ӧ��
    for i=1:NP
        [rndPopFit(i,1),rndPopG(i,:),changeoccur] = evaluate(rndPop(i,:),casedata);
    end
    % �����Ⱥ����
    if isempty(gmaxcons)
        maxcons=ones(1,size(rndPopG,2));
    else
        maxcons=gmaxcons;
    end
    rndPopG(rndPopG<0)=0;
    cons=sum(rndPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,ipf]=sortrows([rndPopFit, cons],[2, 1]);
    %
    newPop(N_mem+1:N_mem+N_rnd, :)=rndPop(ipf(1:N_rnd),:);
    newPopFit(N_mem+1:N_mem+N_rnd,:)=rndPopFit(ipf(1:N_rnd),:);
    newPopG(N_mem+1:N_mem+N_rnd,:)=rndPopG(ipf(1:N_rnd),:);
    
    %% ע��ԭ��Ⱥ�еĽ�
    prePopFit=zeros(N_pre,1);
    prePopG=zeros(N_pre,n_con);
    prePop = zeros(N_pre,DIM);
    
    [swarm, numSpe]=divideSwarmIntoSpecies(pop,popFit,popG,method,phi);
    num_feaSeeds=0;
    pre_pop = zeros(NP, n_con);
    seedSets = [];%TODO
    id_set = ones(N_pre, 1);
    for i=1:numSpe
        if vio(swarm(i).seedID) == 0% feasible seed
            num_feaSeeds=num_feaSeeds+1;
            seedSets=[seedSets, swarm(i).seedID];
            %             if num_feaSeeds <= N_pre
            %                prePop(num_feaSeeds,:) = pop(swarm(i).seedID,:);
            %                prePopG(num_feaSeeds,:) = popG(swarm(i).seedID,:);
            %                prePopFit(num_feaSeeds) = popFit(swarm(i).seedID);
            %             end
        end
    end
    
    if num_feaSeeds >= N_pre        %top N_pre solutions in feasibleSeeds
        prePop(1:N_pre,:) = pop(seedSets(1:N_pre),:);
        prePopG(1:N_pre,:) = popG(seedSets(1:N_pre),:);
        prePopFit(1:N_pre, :) = popFit(seedSets(1:N_pre), :);
    elseif num_feaSeeds < 0 % top N_pre solutions in previous population
        prePop(1:N_pre,:) = pop((1:N_pre),:);
        prePopG(1:N_pre,:) = popG((1:N_pre),:);
        prePopFit(1:N_pre, :) = popFit((1:N_pre), :);
    else % num_feaSeeds < N_pre
        num_added = 0;
        
        flag = zeros(NP, 1);
        
        for i=1:numSpe
            if vio(swarm(i).seedID) == 0% feasible seed
                num=min(n_min, N_pre - num_added);
                num = min(num, swarm(i).size);
                id_set(num_added+1:num_added+num) = swarm(i).particles(1:num);
                num_added = num_added + num;
            end
        end
        
        prePop(1:N_pre,:) = pop(id_set,:);
        prePopG(1:N_pre,:) = popG(id_set,:);
        prePopFit(1:N_pre, :) = popFit(id_set, :);
        flag(id_set) = 1;
        
        index=1:NP;
        id_set = index(flag == 0);
        
        num_remain = N_pre - num_added;
        prePop(num_added+1:N_pre,:) = pop(id_set(1:num_remain),:);
        prePopG(num_added+1:N_pre,:) = popG(id_set(1:num_remain),:);
        prePopFit(num_added+1:N_pre, :) = popFit(id_set(1:num_remain), :);
    end
    
    
    newPop(N_mem+N_rnd+1:NP, :)=prePop;
    newPopFit(N_mem+N_rnd+1:NP,:)=prePopFit;
    newPopG(N_mem+N_rnd+1:NP,:)=prePopG;
    
    %��������
    newPopG(newPopG<0)=0;
    cons=sum(newPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
    [~,index]=sortrows([newPopFit, cons],[2, 1]);
    
    newPop=newPop(index(1:NP),:);
    newPopFit=newPopFit(index(1:NP),:);
    newPopG=newPopG(index(1:NP),:);
    
    
end

%%
statsafterchange();
end


function [ stop ] = outFun(x,optimValues,state )
global nfe;
global has_change_LS;
global frequency;
global dimension;
global numChanges;
%disp('outFun');
%disp(NEval);
%disp(optimValues.iteration);
stop=false;
%mod(NEval,1000);

if ((numChanges+1)*frequency - nfe) - dimension < 0
   % disp('stop==true');
    stop=true;
    has_change_LS=true;
    %disp('x');disp(x);
%     history.fval = [history.fval; optimValues.fval];
     %history.x = [history.x; x];
    %hold off;
else
    %disp('stop==false');
end
end


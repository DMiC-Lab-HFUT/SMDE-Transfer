function [f1,con_err]=rpflow30(x,casedata) %function returns objective function value and sum of constaint vilations
global g_conpara;
% global xl xu  n ng nb e1 e2
%             global err_tol n_con
%          global xu xl nb ng


x(6:11)=round(x(6:11));%???
x(6:9)=[0.9 0.9 0.9 0.9]+ ...
    [0.2 0.2 0.2 0.2].*x(6:9)./[20 20 20 20];

g_conpara=x;
 
%LINE FLOW CALCULATION 
[baseMVA, bus, gen, branch, success, et, loss,ybus]=runpf(casedata);
rloss=sum(real(loss)); %fitness fit1
Vmax=bus(:,12);
Vmin=bus(:,13);
genBUSnum=gen(:,1);

Qmin=gen(:,5)/100;
Qmax=gen(:,4)/100;
QGI=gen(:,3)/100;
limit=branch(:,6);
Slimit=sqrt(branch(:,12).^2+i*branch(:,13).^2);
Serr=sum((Slimit>limit).*abs(limit-Slimit))/baseMVA;
% TO find the error in Qg of gen buses- inequality constraint
Qerr=sum((QGI<Qmin).*(abs(Qmin-QGI)./(Qmax-Qmin))+(QGI>Qmax).*(abs(Qmax-QGI)./(Qmax-Qmin)));
% TO find the error in V of load buses- inequality constraint
VI=bus(:,8);  %V of load buses- inequality constraint
vg=[1 2 5 8 11 13];
VI(vg)=[];
Vmax(vg)=[];
Vmin(vg)=[];
VIerr=sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
%CONSTRAIN VIOLATIONS
error(1)=Qerr;
error(2)=VIerr;
error(3)=Serr;
%OBJECTIVE FUNCTIONS
f1=rloss; %first objective
f2=sum(abs(VI-1));% second objective

con_err=[Qerr,VIerr,Serr]; % sum of constraints violation



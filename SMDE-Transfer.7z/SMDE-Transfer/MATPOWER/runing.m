%function [best,fitbest,time,converge]= z_0de(strategy,nfe,F,CR,NP,casedata,para1,para2,para3,para4,para5)
% strategy:  1: standard DE  2: Trigonometric 3:DEahcSPX 4:DEPSR 5:DESFLS
%      6:jDE  7:OBDE 8 DEGL 9:SaDE
clc
clear
strategy=1;
nfe=6000;

g_nfe=0;
F=0.7;
CR=0.9;
NP=15;
casedata='CASE30';
tic;

Sr(1)=0.475;    % Parameters of Stochastic Ranking
Max_Gen=400;
dSr=(Sr(1)-0.025)/Max_Gen;

[pop,bound,dimension]=initial(casedata,NP);
for i=1:NP
    [popFit(i,1),popG(i,:)] = rpflow(pop(i,:));
end
[best,bestindex]=min(popFit);
V1=zeros(NP,dimension);
V2=zeros(NP,dimension);
V3=zeros(NP,dimension);
V4=zeros(NP,dimension);
V5=zeros(NP,dimension);
consX=zeros(NP,dimension);% for crossover to ensure at least one gen coming from offspring
maskPop=zeros(NP,dimension);
maskOff=zeros(NP,dimension);


% if strategy ~= 4
%     max_t=nfe/NP;
% end
if strategy==6
    Fl=0.1;
    Fu=0.9;
    tau1=para1;
    tau2=para2;
    F=Fl+rand(NP,1)*Fu;
    CR=rand(NP,1);
elseif strategy==4
    Ns=para1;
    NsCount=0;
elseif strategy==7
    init=1;
    [pop,popFit]=z_opV(pop,popFit,bound,NP,casedata,init);
elseif strategy==8
    wG=rand(NP,1);
elseif strategy==9
    SaDE_numst=4; %rand/1/bin; rand-to-best/2/bin; rand/2/bin; current-to-rand/1
    SaDE_LP=50; %learning period
    SaDE_sucmem=zeros(SaDE_numst,SaDE_LP); %sucess memory
    SaDE_faimem=zeros(SaDE_numst,SaDE_LP); %failure memory
    SaDE_prbstr=ones(SaDE_numst,1)*0.25; %the probability to choose strategies
    SaDE_assign=ones(NP,1); % assign strategy to each individual according the SaDE_prbstr
    SaDE_CRmemflag=-1;
    SaDE_CRmem=ones(SaDE_numst,SaDE_LP,NP)*SaDE_CRmemflag; % for recording sucessful CR, -1 is used as the flag of failure
    SaDE_CRpop=ones(NP,1); % CR for each individual
    SaDE_CRst=ones(SaDE_numst,1)*0.5; % CR for each strategy, i.e. CRmk in the paper, initialized to 0.5,
end

%while numel(g_diverse)==0 || g_diverse(numel(g_diverse))>0.01
while g_nfe<nfe
    % for t=1:max_t
    ind=randperm(4);
    rot=(0:NP-1);
    a1=randperm(NP);
    rt=rem(rot+ind(1),NP);
    a2=a1(rt+1);
    rt=rem(rot+ind(2),NP);
    a3=a2(rt+1);
    rt=rem(rot+ind(3),NP);
    a4=a3(rt+1);
    rt=rem(rot+ind(4),NP);
    a5=a4(rt+1);
    V1=pop(a1,:);
    V2=pop(a2,:);
    V3=pop(a3,:);
    V4=pop(a4,:);
    V5=pop(a5,:);
    %--------------------MUTATION--------------------------
    if (strategy ==1)
        off=V1+F*(V2-V3);
    elseif strategy==2
        if(nargin<8)
            mt=0.05;
        else
            mt=para1;
        end
        popFit1 = abs(popFit(a1));
        popFit2 = abs(popFit(a2));
        popFit3 = abs(popFit(a3));
        maskT=rand(NP,1)<mt;
        maskT=repmat(maskT,1,dimension);
        maskC=maskT<0.5;
        p1=popFit1./(popFit1+popFit2+popFit3);
        p2=popFit2./(popFit1+popFit2+popFit3);
        p3=popFit3./(popFit1+popFit2+popFit3);
        V4=(V1+V2+V3)/3+repmat((p2-p1)',1,dimension).*(V1-V2)+repmat((p3-p2)',1,dimension).*(V2-V3)+repmat((p1-p3)',1,dimension).*(V3-V1);
        V5=V1+F*(V2-V3);
        off=maskT.*V4+maskC.*V5;
    elseif strategy==3
        np=para1;
        epsilon=para2;
        P=zeros(np,dimension);
        P(1,:)=pop(bestindex,:);
        a=randint(np-1,1,[1,NP]);
        P(2:np,:)=pop(a(1:np-1),:);
        while(1)
            O=sum(P)/np;
            r=rand();
            y1=O+epsilon.*(P(1,:)-O);
            c=zeros(1,dimension);
            for k=2:np
                y2=O+epsilon*(P(k,:)-O);
                c=(y1-y2+c)*r^(1/k);
                y1=y2;
            end
            c=c+y2;
            c_fit=z_evaluate(c,1,casedata);
            if  c_fit<best
                P(1,:)=c;
                best=c_fit;
            else
                pop(bestindex,:)=P(1,:);
                popFit(bestindex)=best;
                V1(a1==bestindex,:)=P(1,:);
                V2(a2==bestindex,:)=P(1,:);
                V3(a3==bestindex,:)=P(1,:);
                off=V1+F*(V2-V3);
                break;
            end
        end
    elseif strategy==4
        off=V1+F*(V2-V3);
    elseif strategy==5
        tau=para1;
        phi=(1+sqrt(5))/2;
        off=V1+F.*(V2-V3);
        if rand<tau
            a=-1.2;
            b=1.2;
            for budget=1:8
                F1=b-(b-a)/phi;
                F2=a+(b-a)/phi;
                imask=rand(1,dimension)>CR;
                imask(randint(1,1,[1,dimension]))=1;
                off1=V1(bestindex,:)+F1.*(V2(bestindex,:)-V3(bestindex,:));
                off1=pop(bestindex,:).*(imask<0.5)+off1.*imask;
                
                imask=rand(1,dimension)>CR;
                imask(randint(1,1,[1,dimension]))=1;
                off2=V1(bestindex,:)+F2.*(V2(bestindex,:)-V3(bestindex,:));
                off2=pop(bestindex,:).*(imask<0.5)+off2.*imask;
                
                [f1]=z_evaluate(off1,1,casedata,bound);
                [f2]=z_evaluate(off2,1,casedata,bound);
                if f1<f2
                    b=F2;
                    Fbest=F1;
                else
                    a=F1;
                    Fbest=F2;
                end
            end
            off(bestindex,:)=V1(bestindex,:)+Fbest.*(V2(bestindex,:)-V3(bestindex,:));
        end
    elseif strategy==6
        Fn=Fl+Fu*rand(NP,1);
        Frand=rand(NP,1);
        Fn(find(Frand>tau1))=F(find(Frand>tau1));
        off=V1+repmat(Fn,1,dimension).*(V2-V3);
        CRn=rand(NP,1);
        CRrand=rand(NP,1);
        CRn(find(CRrand>tau2))=CR(find(CRrand>tau2));
        CR=repmat(CRn,1,dimension);
    elseif strategy==7
        off=V1+F*(V2-V3);
    elseif strategy==8
        alpha=para1;
        beta=para2;
        k=para3;
        off=pop+alpha.*(repmat(pop(bestindex,:),NP,1)-pop)+beta.*(V1-V2);
        n=randperm(NP);
        n1=n+NP-k;
        n2=n+NP+k;
        for s=1:NP
            m=[n1(s):n2(s)];
            m=mod(m+NP-1,NP)+1;
            [best,index]=min(popFit(m));
            index=mod((index+n1(s)-2)+NP,NP)+1;
            V1(s,:)=pop(s,:)+alpha.*(pop(index,:)-pop(s,:))+beta.*(V3(s,:)-V4(s,:));
        end
        wG1=wG+F.*(repmat(wG(bestindex),NP,1)-wG)+F.*(wG(a1)-wG(a2));
        wG1(find(wG1(:)>0.95))=0.95;
        wG1(find(wG1(:)<0.05))=0.05;
        off=repmat(wG,1,dimension).*off+repmat((1-wG),1,dimension).*V1;
    elseif strategy==9 %SaDE
        if(g_nfe/NP+1>SaDE_LP) % Equation (14) of the paper
            Skg=sum(SaDE_sucmem,2)./...
                (sum(SaDE_faimem,2)+sum(SaDE_sucmem,2))+0.01;
            SaDE_prbstr=Skg./sum(Skg);
        end
        SaDE_assign=SUS(SaDE_prbstr,NP);
        F=repmat(randn(NP,1),1,dimension)*0.3+0.5;
        K=repmat(rand(NP,1),1,dimension);
        mask=SaDE_assign==1;
        off(mask,:)=V1(mask,:)+ F(mask,:).*(V2(mask,:)-V3(mask,:)); % rand/1/bin
        mask=SaDE_assign==2;
        Vbest=repmat(pop(bestindex,:),NP,1);
        off(mask,:)=pop(mask,:)+F(mask,:).*(Vbest(mask,:)-pop(mask,:)) + F(mask,:).*(V1(mask,:)-V2(mask,:)) + F(mask,:).*(V3(mask,:)-V4(mask,:)); %rand-to-best/2/bin
        mask=SaDE_assign==3;
        off(mask,:)= V1(mask,:)+F(mask,:).*(V2(mask,:)-V3(mask,:)) + F(mask,:).*(V4(mask,:)-V5(mask,:)); %rand/2/bin
        mask=SaDE_assign==4;
        off(mask,:)=pop(mask,:)+K(mask,:).*(V1(mask,:)-pop(mask,:)) +F(mask,:).*(V2(mask,:)-V3(mask,:)); % current-to-rand/1
        
    end
    %------------------Crossover---------------------------
    if(strategy==9)
        for i=1:SaDE_numst-1
            if(g_nfe/NP+1>SaDE_LP)
                indics=SaDE_CRmem(i,:,:)~=SaDE_CRmemflag;
                SaDE_CRst(i)=median(SaDE_CRmem(i,indics));
            end
            SaDE_CRpop(SaDE_assign==i)=randn(sum(SaDE_assign==i),1)*0.1+SaDE_CRst(i);
        end
        SaDE_CRpop(SaDE_assign==4)=1;
        maskOff=rand(NP,dimension)<repmat(SaDE_CRpop,1,dimension);
        consX=full(sparse(1:NP,randint(1,NP,[1 dimension]),1,NP,dimension));
        maskOff(consX==1)=1; % if j=jrand
        maskPop=maskOff<0.5;
        off=maskOff.*off+maskPop.*pop;
    else
        maskOff=rand(NP,dimension);
        off(find(maskOff>CR))=pop(find(maskOff>CR));
    end
    %-----------------Bounder violation handling%%%%%
    boundUp=repmat(bound(:,2)',NP,1);
    exceedUp=off>boundUp;
    offset=rand(NP,dimension).*(boundUp-pop);
    off(exceedUp)=pop(exceedUp)+offset(exceedUp);
    boundLow=repmat(bound(:,1)',NP,1);
    exceedLow=off<boundLow;
    offset=rand(NP,dimension).*(pop-boundLow);
    off(exceedLow)=pop(exceedLow)-offset(exceedLow);
    % -----------------end boundary violation handling-----------------
    
    %% evaluate
    for i=1:NP
        [offFit(i,1),offG(i,:)] = rpflow(off(i,:));
    end
    g_nfe=g_nfe+NP;
    %% Stochastic Selection
    
    A=[pop;off];
    B=[popFit;offFit];
    G=[popG;offG];
    
    %% Superiority of Feasible Solutions
    cons=(G>0).*G;
    cons_max=max(cons,[],1);
    nzindex=find(cons_max~=0);
    
    if isempty(nzindex)
        tcons=zeros(size(A,1),1);
    else
        tcons=sum(cons(:,nzindex)./repmat(cons_max(:,nzindex),size(A,1),1),2)./sum(1./cons_max(:,nzindex));
    end
    gen=g_nfe/NP;
    if gen>1 && gen< Max_Gen
        Sr(gen)=Sr(gen-1)-dSr;
    elseif(gen>=Max_Gen)
        Sr(gen)=0.025;
    end
    %% Stochastic selection
    for kk=1:NP
        if(rand<Sr(gen))
            if((B(NP+kk) < B(kk)))
                pop(kk,:)= A(NP+kk,:);
                popFit(kk,:)= B(NP+kk,:);
                popG(kk,:)  = G(NP+kk,:);
                ttcons(kk,:) = tcons(NP+kk,:);
            else
                ttcons(kk,:) = tcons(kk,:);
            end
        else
            if((tcons(NP+kk) < tcons(kk)) | ((tcons(NP+kk)==0 & tcons(kk)==0) & (B(NP+kk) < B(kk))))
                pop(kk,:)= A(NP+kk,:);
                popFit(kk,:)= B(NP+kk,:);
                popG(kk,:)  = G(NP+kk,:);
                ttcons(kk,:) = tcons(NP+kk,:);
            else
                ttcons(kk,:) = tcons(kk,:);
            end
        end
    end
    
    %--------------------End Stochastic selection
    %%
    
    if strategy==8
        wG(succ)=wG1(succ);
    end
    if (strategy==9)
        for i=1:4
            SaDE_sucmem(i,mod(g_nfe/NP,SaDE_LP)+1)=sum(succ(SaDE_assign==i));
            SaDE_faimem(i,mod(g_nfe/NP,SaDE_LP)+1)=sum(SaDE_assign==i)-sum(succ(SaDE_assign==i));
        end
        for i=1:3
            SaDE_CRmem(i,mod(g_nfe/NP,SaDE_LP)+1,succ' & (SaDE_assign==i) )=SaDE_CRpop(succ' & (SaDE_assign==i) );
            SaDE_CRmem(i,mod(g_nfe/NP,SaDE_LP)+1,(~succ)' & (SaDE_assign==i) )= SaDE_CRmemflag;
        end
    end
    if strategy==4
        if NsCount<floor(g_nfe/(nfe/Ns))
            NP=floor(NP/2);
            pop(find(popFit(1:NP)>popFit(NP+1:NP*2)),:)=pop(find(popFit(1:NP)>popFit(NP+1:NP*2))+NP,:);
            popFit(find(popFit(1:NP)>popFit(NP+1:NP*2)))=popFit(find(popFit(1:NP)>popFit(NP+1:NP*2))+NP);
            pop=pop(1:NP,:);
            V1=pop;
            popFit=popFit(1:NP);
            popFit1=popFit;
            NsCount=NsCount+1;
        end
    elseif strategy==7
        if rand <para1
            [pop,popFit]=z_opV(pop,popFit,bound,NP,casedata,0);
        end
    end
   %% find the best individual
        feasindex=find(ttcons==0);
        if isempty(feasindex)
            [gbesttcons,ibest]=min(ttcons);
            gbestval=popFit(ibest);
            gbest = pop(ibest,:);
        else
            [gbestval,ibest]=min(popFit(feasindex));
            gbesttcons=ttcons(feasindex(ibest));
            gbest = pop(feasindex(ibest),:);
        end
        disp([gen,gbestval]);
        if(gen ==1)
            thegbestval = gbestval;
            thegbesttcons = gbesttcons;
        elseif((gbesttcons < thegbesttcons) | (gbesttcons==0 & thegbesttcons ==0 & gbestval < thegbestval))
            thegbestval = gbestval;
            thegbesttcons = gbesttcons;
        end
        W(gen,1)=thegbestval;
        W(gen,2)=thegbesttcons;
        W(gen,3)=g_nfe;
        
%         if(isempty(feval) && thegbesttcons ==0)
%             feval = nfeval;
%         end
        

end

time=toc;
% figure(1);
% plot(g_record,'-r.')
% title(['��ֳ���']);
% xlabel('��������');
% ylabel('��������ֵ');
% grid
% figure(2);
% plot(g_diverse,'-r.')
% title(['duoyangxing']);
% xlabel('��������');
% ylabel('��������ֵ');
% grid
% disp(pop(bestindex,:));
% disp(best);
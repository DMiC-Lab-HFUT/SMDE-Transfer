function FM=transSimilarity(M,flag)
n= size(M,1);
FM=zeros(n,n);
for i=1:n
    for j =1:n
        if flag==1%������
            m=1;%�ɵ���
            if i==j
                FM(i,j)=1;
            else
                FM(i,j)=sum(M(i,:).*M(j,:))/m;
            end
        elseif flag==2%������
            if size(M,1)<=2
                FM=[1,0;0,1];
            else
                m1=mean(M(i,:));
                m2=mean(M(j,:));
                son=abs(sum((M(i,:)-m1).*(M(j,:)-m2)));
                mother=sqrt(sum((M(i,:)-m1).*(M(i,:)-m1))*sum((M(j,:)-m2).*(M(j,:)-m2)));
                FM(i,j)=son/mother;
            end
            
        elseif flag==3%������
            if i==j
                FM(i,j)=1;
            else
                FM(i,j)=sum(Fmin(M(i,:),M(j,:)))/sum(Fmax(M(i,:),M(j,:)));
            end
            
        elseif flag==4%������
            FM(i,j)=2*sum(Fmin(M(i,:),M(j,:)))/sum(Fadd(M(i,:),M(j,:)));
        elseif flag==5%������
            FM(i,j)=sum(Fmin(M(i,:),M(j,:)))/sum(Fmulsqrt(M(i,:),M(j,:)));
        elseif flag==6
            FM(i,j)=exp(-sum(Fredabs(M(i,:),M(j,:))));
        elseif flag==7
            C=0.1;%�ɵ���
            if i==j
                FM(i,j)=1;
            else
                FM(i,j)=1-C*sum(Fredabs(M(i,:),M(j,:)));
            end
        elseif flag==8%������
            FM(i,j)=(sum(M(i,:).*M(j,:)))/(sqrt(sum(M(i,:).*M(i,:))*sum(M(j,:).*M(j,:))));
        end
    end
end
end

function v=Fmin(x,y)
m=size(x,2);
v=zeros(1,m);
for i = 1:m
    v(1,i)=min(x(1,i),y(1,i));
end
end
function v=Fmax(x,y)
m=size(x,2);
v=zeros(1,m);
for i = 1:m
    v(1,i)=max(x(1,i),y(1,i));
end
end
function v=Fadd(x,y)
m=size(x,2);
v=zeros(1,m);
for i = 1:m
    v(1,i)=x(1,i)+y(1,i);
end
end
function v=Fmulsqrt(x,y)
m=size(x,2);
v=zeros(1,m);
for i = 1:m
    v(1,i)=sqrt(x(1,i)*y(1,i));
end
end
function v=Fredabs(x,y)
m=size(x,2);
v=zeros(1,m);
for i = 1:m
    v(1,i)=abs(x(1,i)-y(1,i));
end
end
function [fitness] = myFun(x)%,g
global casedata_LS;
global fileName_LS;

[fitness, conv, changeoccur]=evaluate(x, casedata_LS, fileName_LS);

end

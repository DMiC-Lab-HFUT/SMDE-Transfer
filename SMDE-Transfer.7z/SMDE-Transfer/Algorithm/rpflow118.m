function [f1,con_err]=rpflow118(x,casedata)
global g_conpara;
global cgen;

numDynGen=numel(cgen);
numGen=54-numDynGen;
x(numGen-1+numGen+1:end)=round(x(numGen-1+numGen+1:end));
x(2*numGen:2*numGen+8)=repmat(0.9, 1, 9) + 0.01*x(2*numGen:2*numGen+8); 
 

baseMVA=100;

g_conpara=x;

[baseMVA, bus, gen, branch, success, et, loss,ybus]=runpf(casedata);
rloss=sum(real(loss)); %fitness fit1
Vmax=bus(:,12);
Vmin=bus(:,13);
genBUSnum=gen(:,1);
Qmin=gen(:,5)/100;
Qmax=gen(:,4)/100;
QGI=gen(:,3)/100;
limit=1.5.*(branch(:,6));
Slimit=sqrt(branch(:,12).^2+i*branch(:,13).^2);
Serr=sum((Slimit>limit).*abs(limit-Slimit))/baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr=sum((QGI<Qmin).*(abs(Qmin-QGI)./(Qmax-Qmin))+(QGI>Qmax).*(abs(Qmax-QGI)./(Qmax-Qmin)));

% TO find the error in V of load buses- inequality constraint
VI=bus(:,8);  %V of load buses- inequality constraint
vg=[1     4     6     8    10    12    15    18    19    24    25    26    27    31    32    34    36    40    42    46    49    54    55    56    59    61 ...
62    65    66    69    70    72    73    74    76    77    80    85    87    89    90    91    92    99   100   103   104   105   107   110   111   112   113   116];

VI(vg)=[];
Vmax(vg)=[];
Vmin(vg)=[];
VIerr=sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));

error(1)=Qerr;
error(2)=VIerr;
error(3)=Serr;

f1=rloss;
f2=sum(abs(VI-1));

con_err=[Qerr,VIerr,Serr]; % sum of constraints violation

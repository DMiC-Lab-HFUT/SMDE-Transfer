function runPaper_comparison_fig13()%casedata,seeds,scheme,hybrid
%% Fig. 12

%% Preprocessing
clear;
clear global;
distcomp.feature( 'LocalUseMpiexec', false );
currentFolder=pwd;
addpath([currentFolder,'\MATPOWER']);
addpath([currentFolder,'\Algorithm']);
folder='Results\';
if exist(folder,'file')==0
    mkdir(folder);
end
flag_parallel_run = true;% true, false
flag_test = false; % true, false

%% Experimental settings
numChanges=10; % Total number of changes per run
methods=[0:3]; % To decide the set of compared algorithms
seeds=1:20; % the set of random seeds
% Note that if you want to change the settings of $num_cbus$ and $numDynGen$,
% the corresponding codes in the test problms should also be changed.
num_cbus =5; % the number of dynamic buses (to simulate the dynamics of demanded active power)
numDynGen=2; % the number of dynamic generator buses (to simulate the dynamics of renewable power generations)
probs={'dCase57', 'dCase118'};  % The set of test problems
numRuns=numel(seeds); % The total numbel of independent runs
changehandle=6;%not used
usearchive=2;%not used
numMemSize = 200;%not used
method = 2;
note='SMEDE-II'; % The first version of the prospoed algorithm
if flag_test == true % For DEBUG purpose
    seeds = 1:2;
    numRuns=numel(seeds);
    numChanges=10;
    methods=0;
end

%% Parameter settings
phi=1.0; % The clustering parameter of NBC
DE_F_weight=0.85; % the scale factor F of DE
DE_CR=0.9; % crossover rate CR
NP=50; % the population size NP
threshold_value=7; %the parameter $gen_threshold$
nbc_parameter=2; %The parameter ��of the ��-NBC
DE_strategy=2; %  The DE mutation strategy
case_renewablePower=1; %1: ���ܷ���(Wind Power)  2��̫���ܷ��� (Solar Power)
DE_CR_weightSet=0.1:0.1:0.9;
DE_F_weightSet=0.1:0.1:0.9;
%% Main loop
for threshold_value= 3:10
    disp(['SMEDE-II  nbc_parameter', num2str(nbc_parameter),' threshold_value: ',num2str(threshold_value)]);
    for i=1:2 % To decide the test problem (1: IEEE 57-bus; 2: IEEE 118-bus case )
        casedata = probs{i}; % the test problem
        % The change frequency
        % The problem would be changed every $frequency$ FEs
        if i==1
            frequency = 5000; % For the IEEE 57-bus case
        elseif i==2
            frequency = 10000; % For the IEEE 118-bus case
        end
        % Termination condition of each run
        MaxNfe=numChanges*frequency;
        
        % Intermediate variables for the measurements
        feasibleTime_all=zeros(numRuns,1);
        trackingError_all=zeros(numRuns,1);
        nIter_all=zeros(numRuns,1);
        numChanges_all=zeros(numRuns,1);
        numOfFeaGen_all=zeros(numRuns,1);
        feasibleTime=0;
        numFeaPeriods=0;
        trackingError_sum = 0;
        total_vio = 0;
        total_vio_all = zeros(numRuns,1);
        output=0;
        
        fileName=[casedata,'_method',num2str(method),'_bus',num2str(num_cbus),'_gen',...
            num2str(numDynGen),'_NP',num2str(NP),'_phi',num2str(phi*10),...
            '_F',num2str(DE_F_weight),'_threshold',num2str(threshold_value),'_CR',num2str(DE_CR),'_nbc',num2str(nbc_parameter),'_Power',num2str(case_renewablePower),'_DE',num2str(DE_strategy)];
        
        %% Load optimal values
        disp(['case_renewablePower:',num2str(case_renewablePower)]);
        ideal_fileName=['data/Ideal_results/ideal_',casedata,'_method1_bus5_gen2_NP50_phi10_F0.85_threshold7_CR0.9_nbc2_Power',num2str(case_renewablePower),'_run1.mat'];
        load(ideal_fileName, 'bestSolutionEachPeriod');
        optimalValues=bestSolutionEachPeriod;
        
        %% Conduct $numRuns$ independent times
        if flag_parallel_run == true
            delete(gcp('nocreate'));
            try
                parpool('local',numRuns);
            catch ce
                parpool;
                fail_p=gcp('nocreate');
                fail_size=fail_p.NumWorkers;
                display(ce.message);
                display(strcat('�����size����ȷ�����õ�Ĭ������size=',num2str(fail_size)));
            end
            spmd(numRuns)
                fileName2=[fileName,'_run',num2str(labindex)];
                %% Run the improved DE algorithm
                [output1]=dSRDE(changehandle,casedata,num_cbus,numDynGen,...
                    fileName2,MaxNfe,usearchive,labindex,method,numMemSize,...
                    NP,frequency,phi,DE_strategy, DE_F_weight,DE_CR,threshold_value,nbc_parameter,case_renewablePower);
            end
        else
            for seed=seeds
                fileName2=[fileName,'_run',num2str(seed)];
                %% Run the improved DE algorithm
                [output]=dSRDE(changehandle,casedata,num_cbus,numDynGen,...
                    fileName2,MaxNfe,usearchive,seed,method,numMemSize,...
                    NP,frequency,phi,DE_strategy, DE_F_weight,DE_CR,threshold_value,nbc_parameter,case_renewablePower);
            end
        end
        
        for seed=seeds
            %% The experimental results for the current run
            if flag_parallel_run == true
                if numRuns == 1
                    output=output1;
                else
                    output=output1{seed};
                end
            end
            nIter_all(seed)=output.nIter;
            numChanges_all(seed)=output.numChanges;
            numOfFeaGen_all(seed)=output.numOfFeaGen;
            feasibleTime_all(seed)=+output.feasiblePeriods;
            feasibleTime=feasibleTime+output.feasiblePeriods;
            
            %% Measurements
            for ii=1:numChanges
                bestObtained = output.bestSolutionEachPeriod(ii, 2);
                optimum = optimalValues(ii,2);
                total_vio = total_vio+sum(output.bestSolutionEachPeriod(ii, 3:5));
                total_vio_all(seed) = total_vio_all(seed) + sum(output.bestSolutionEachPeriod(ii, 3:5));
                
                if(sum(output.bestSolutionEachPeriod(ii, 3:5)))==0 % A feasible solution was found
                    numFeaPeriods=numFeaPeriods+1;
                    error=bestObtained-optimum;% The fitness error
                    if error > 0
                        trackingError_all(seed)=trackingError_all(seed)+error;
                        trackingError_sum=trackingError_sum + error;
                    end
                end
            end
        end
        %% Feasible time ratio
        feasibleTimeRatio=feasibleTime/sum(numChanges_all);
        %% Tracking error
        %             trackingError_sorted = (trackingError_all);
        %             for ii =1:numChanges
        %                 trackingError_sorted =trackingError_sorted/feasibleTime_all(ii);
        %             end
        trackingError = trackingError_sum/feasibleTime;
        
        disp([num2str(feasibleTimeRatio),' ',num2str(trackingError), ' ', num2str(mean(total_vio_all)/numChanges),' ', num2str(std(total_vio_all))]);
        
        folder1=[folder,'\Measurements\'];
        if exist(folder1,'file')==0
            mkdir(folder1);
        end
        save([folder1,fileName,'.mat'],'trackingError','numChanges_all','feasibleTime','method','feasibleTimeRatio','note','output','trackingError_all');
        delete(gcp('nocreate'));
    end
end
end



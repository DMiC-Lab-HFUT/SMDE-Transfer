function memindv=retrieveLocalMem(loads,PG,value)
% simliar retrieval scheme

global localMemory;% structure: <loads, PG, numSpe, variables, fitness, cons>
global g_caseconfig;
memindv=[];
if isempty(localMemory)
    return;
end

index_variables=(numel(g_caseconfig.indics)+2+1):(size(localMemory,2)-4);

dif=localMemory(:,1:numel([loads, PG]))-repmat([loads, PG],size(localMemory,1),1);
means=mean(localMemory(:,1:numel([loads, PG])), 1);%modified by Chenyang Bu
normdif=abs(dif)./repmat(means,size(localMemory,1),1);
dis=sum(normdif,2);
radius=value.radius;
tao_1=value.nfe;
[~,index]=sort(dis);
index_simliar = dis<radius*numel([loads, PG]);
numIndSimilar=sum(index_simliar);
if numIndSimilar <= tao_1 && numIndSimilar > 0
    memindv = localMemory(index(index_simliar), index_variables);
else
    % P(n) = alpha * n + beta
    alpha=-2*tao_1/(numIndSimilar*(numIndSimilar+1));
    beta=2*tao_1/(numIndSimilar+1);
    % Assign the selection probabilities for these memory individuals,
    % i.e., P(0), P(1), ..., P(N-1)
    % The best one is ranked 0, and the next one is ranked 1, and so on
    % P(n) has the following properties:
    % 1) P(n) > P(n+1) > 0
    % 2) sum(P(n)) = tao_1
    probs=alpha*(0:numIndSimilar-1)+beta;%corrected by Chenyang Bu
    % the index of selected individuals
    selected=SUS(probs,tao_1);
    % the selected memory individuals
    memindv=localMemory(index(selected),index_variables);
end

end
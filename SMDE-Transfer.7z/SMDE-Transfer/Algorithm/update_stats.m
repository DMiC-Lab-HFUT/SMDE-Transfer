 function update_stats(v,fit,conv)
%% record performance data
%% global declartion
global nfe;
global intvRecord;
global gmaxcons;
global gbestfit;
global gbestcons;
global gbest;
global single_run;
global fullrecord;
global is_DEBUG;
global nIter;
nfe=nfe+1;
if(nfe==1) %initialization
    gmaxcons=conv+0.001;
    gbestfit=fit;
    gbestcons=conv;
    gbest=v;
    
else
    gmaxcons(gmaxcons<conv)=conv(gmaxcons<conv);
    %% update the best individual
    if debbetter(fit,conv,gbestfit,gbestcons,gmaxcons)
        gbest=v;
        gbestfit=fit;
        gbestcons=conv;
    end
    
end
if is_DEBUG == 1
    %     if(mod(nfe,intvRecord)==0)
    %         gen=nfe/intvRecord;
%     gen=nIter+1;
%     single_run(gen,1)=gbestfit;
%     single_run(gen,2:4)=gbestcons;
%     single_run(gen,4+1:4+numel(gbest))=gbest;
    %     end
    fullrecord(nfe,1)=gbestfit;
    fullrecord(nfe,2:4)=gbestcons;
    fullrecord(nfe,4+1:4+numel(gbest))=gbest;
end
end
function [pop, popFit, popG,changeoccur]=actionForChange(changehandler,casedata,NP,pop,popFit,popG,swarm,usearchive,bound)
global method;
global gmaxcons;
global g_caseconfig;
switch (changehandler)
    case{0} %do nothing, just reevaluate all the individuals
        for inp=1:NP
            [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        end
    case{1} % reinitialization
        %         pop=initial(casedata,NP);
        %         for inp=NP:-1:1
        %             [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        %         end
        save2mem(g_caseconfig.formerloads', g_caseconfig.PG', pop, popFit, popG,swarm);
        initSize = 2*NP;
        [~, dimension]=size(pop);
        [pop] = initialSwarm(initSize,bound,dimension,2);
        for i=1:initSize
            [popFit(i,1),popG(i,:),changeoccur] = evaluate(pop(i,:),casedata);
        end
        
        if isempty(gmaxcons)
            maxcons=ones(1,size(popG,2));
        else
            maxcons=gmaxcons;
        end
        popG(popG<0)=0;
        cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
        [~,index]=sortrows([popFit, cons],[2, 1]);
        
        pop=pop(index(1:NP),:);
        popFit=popFit(index(1:NP),:);
        popG=popG(index(1:NP),:);
    case{2} %mean-based immigrants
        pf=popFit;
        [pf,ipf]=sort(pf,1,'descend');
        if usearchive==2
            save2mem(g_caseconfig.formerloads',numSpe);
        end
        impop=memImmigrants(10,bound);
        if ~isempty(impop)
            ire=ipf(1:size(impop,1));
            pop(ire,:)=impop;
        end
        for inp=1:NP
            [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        end
    case{3} %environment-based immigrant
        %                 pf=popFit;
        %                 [pf,ipf]=sort(pf,1,'descend');
        %                 nimm=10;
        %                 if nimm>0
        %                     pop(ipf(1),:)=retrievemem(g_caseconfig.loads',1);
        %                     ire=ipf(2:nimm);
        %                     pop(ire,:)=memimmigrants(nimm-1,bound,'closest',g_caseconfig.loads');
        %                 end
        %                 while(changeoccur)
        %                     for inp=1:NP
        %                         [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        %                         if changeoccur
        %                             break
        %                         end
        %                     end
        %                 end
    case{4} % copy memory individuals
        %                 pf=popFit;
        %                 [pf,ipf]=sort(pf,1,'descend');
        %                 nret=10;
        %                 if nret>0
        %                     memindv=retrievemem(g_caseconfig.loads',nret);
        %                     pop(ipf(1:size(memindv,1)),:)=memindv;
        %                 end
        %                 while(changeoccur)
        %                     for inp=1:NP
        %                         [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        %                         if changeoccur
        %                             break
        %                         end
        %                     end
        %                 end
    case{5} % test all the schemes
        %                 pf=popFit;
        %                 [pf,ipf]=sort(pf,1,'descend');
        %                 %step 1 record individuals in Kd-Tree memory
        %                 if usearchive==2
        %                     save2mem(g_caseconfig.formerloads',pop(ipf(NP),:),popFit(ipf(NP),:),popG(ipf(NP),:));
        %                 end
        %                 % step 2 retrieve memory individuals and insert them into pop
        %                 nret=5;
        %                 if nret>0
        %                     memindv=retrievemem(g_caseconfig.loads',nret);
        %                     pop(ipf(1:size(memindv,1)),:)=memindv;
        %                 end
        %                %step 3 add random individual; random immigrant is bad
        % %                nrandindv=ceil(NP*reinitrate);
        % %                ire=ipf(nret+1:nret+nrandindv);
        % %                pop(ire,:)=initial(casedata,numel(ire));
        %                % step 4 memory immigrants
        %                 nimm=10;
        %                 if nimm>0
        %                     ire=ipf(nret+1:nret+nimm);
        %                     pop(ire,:)=memimmigrants(nimm,bound);
        %                     %pop(ire,:)=memimmigrants(nimm,bound,'closest',g_caseconfig.loads');
        %                 end
        %                 %evaluate individuals
        %                 while(changeoccur)
        %                     for inp=1:NP
        %                         [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        %                         if changeoccur
        %                             break
        %                         end
        %                     end
        %                 end
    case{6}  % scheme used in the paper
        %             pop=changehandler6(pop,popFit,popG,bound,swarm);
        [pop,popFit,popG,changeoccur]=new_changehandler64(pop,popFit,popG,bound,swarm,casedata,usearchive);
%         if method == 0 || method == 3
%             for inp=1:NP
%                 [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
%             end
%         end
        
    case{7} % copy close individual from the memory
        pf=popFit;
        [pf,ipf]=sort(pf,1,'descend');
        if usearchive==2
            save2mem(g_caseconfig.formerloads',seeds);
        end
        nmfe=5;
        value.radius=0.08;
        value.nfe=nmfe;
        memindv=retrievemem(g_caseconfig.loads',value,'radius');
        if ~isempty(memindv)
            pop(ipf(1:value.nfe,1),:)=memindv;
        end
        %  pop(ipf(nmfe+1:nmfe+10),:)=memimmigrants(10,bound);
        for inp=1:NP
            [popFit(inp),popG(inp,:),changeoccur]=evaluate(pop(inp,:),casedata);
        end
    otherwise
        % no operation
end
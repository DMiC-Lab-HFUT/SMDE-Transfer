function [N_pre, N_rnd, N_Mem, N_replaced, MemIdSet] = new_determine_pop_percentage(simIndex,lmd, mu_last_env, NP)
%% The following is to determine the percentage of memory
...and random solutions in the new population based on the
...fuzzy similarity.
    
global ratioRnd_min;
global memory;
global r_thre;
r_thre=0.6;
ratioRnd_min=0.2;
N_replaced = max(ceil(NP*(1-mu_last_env)), ceil(NP*ratioRnd_min));
N_pre = NP - N_replaced;
MemIdSet_index = simIndex;
num_envs = 1:numel(memory);
MemIdSet = num_envs(MemIdSet_index);
if isempty(MemIdSet)
    N_Mem = 1;
    MemIdSet = mu_max.id;
else
    %��ʱ���գ��������޸ģ��޿�ѧ�ԣ�����������
    N_Mem=ceil(N_replaced*lmd);
    %ID = mu_max.id;
    %N_Mem = min(memory(ID).numLM, ceil(N_replaced*lmd));
end
N_rnd = N_replaced - N_Mem;


end
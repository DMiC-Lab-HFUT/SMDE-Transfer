function flag=debbetter(fit1,conv1,fit2,conv2,gmaxcon)
global gmaxcons;
if nargin<5
    gmaxcon=gmaxcons;
end
NP=numel(fit1);
conv1(conv1<=0)=0;
conv2(conv2<=0)=0;
if(sum(gmaxcon)>0)
    tcon1=sum(conv1./repmat(gmaxcon,NP,1),2)./sum(1./gmaxcon);
    tcon2=sum(conv2./repmat(gmaxcon,NP,1),2)./sum(1./gmaxcon);
    flag = (tcon1<tcon2) | (tcon1==0 & tcon2==0 & fit1 <fit2);
else
    flag = fit1 < fit2;
end
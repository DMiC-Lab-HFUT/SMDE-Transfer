function [simIndex,lmd]=ada_division(dis_all,FM)
n=size(FM,1);
F_max=0;
lmd=0;
for temp_lmd=0.1:0.1:0.9
    F=0;
    clus=[];
    for i=2:n
        for j=1:i
            if FM(i,j)>=temp_lmd
                len=size(clus,1);
                if len==0
                    if i==j
                        clus=[clus;[i]];
                    else
                        clus=[clus;[i,j]];
                    end
                else
                    for l = 1:len
                        %���j�����еĻ����еĻ�����i�ӽ�ȥ���У���Ϊ�����ķ���
                        if ~isempty(find(clus(l,:)==j))
                            clus(l,:)=[clus(l,:),i];
                        end
                    end
                end
            else
                clus=[clus;[i]];
            end
        end
    end
    len=size(clus,1);
    if len==1 || len==n
        continue;
    end
    %��ʼ����Fͳ����
    x_means=mean(dis_all,1);
    dis_c=[];
    n_len=[];
    for i =1:len
        dis_c=[dis_c;dis_all(clus(i,:),:)];
        n_len=[n_len;size(clus(i,:),2)];
    end
    x_cmeans=zeros(len,size(dis_all,2));
    for i =1:len
        x_cmeans(i,:)=mean(dis_c(i,:,:),1);
    end
    son=sum(n_len.*distance_calculate_2(x_cmeans,x_means));
    mother=[];
    for i=1:len
        mother=[mother;distance_calculate_2(dis_c(i,:,:),x_cmeans(i,:))];
    end
    mother=sum(mother);
    F=((n-len)/(len-1))*son/mother;
    if F>=F_max
        lmd=temp_lmd;
        F_max=F;
        simIndex=[];
        for i=1:n-1
            if FM(n,i)>=lmd
                simIndex=[simIndex,i];
            end
        end
    end
end

end

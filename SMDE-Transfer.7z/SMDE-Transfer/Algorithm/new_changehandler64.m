function [newPop,newPopFit,newPopG,changeoccur]=new_changehandler64(pop,popFit,popG,bound,swarm,casedata,usearchive)
global g_caseconfig;
global g_memory;
global gmaxcons;
global method;
global phi;
global memory;
global n_min;
global s2;
global memorynow;
phi=1;
n_min = 3;%����
changeoccur=0;
[NP, DIM]=size(pop);
[~, n_con] = size(popG);


%% Update the memory sets todo:
if method==6 && usearchive ==0
    save2memnow(g_caseconfig.formerloads', g_caseconfig.formerPG', pop, popFit, popG,swarm);  
else
    save2mem(g_caseconfig.formerloads', g_caseconfig.formerPG', pop, popFit, popG,swarm); %��֤�������㷨ʱmemory����������  
end
if method == 3
    %% similar retrieval scheme
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% mean-based immigrants scheme
    numImmigrants = 10;
    imPop=memImmigrants(numImmigrants, bound);
    replacePool=[replacePool;imPop];
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    newPop=pop;
    if ~isempty(g_memory)
        % sort the swarm in descending order according to the fitness
        %         [~,ipf]=sort(popFit,1,'descend');
        %         newPop(ipf(1:numReplace),:)=replacePool;
        
        % sort the swarm in descending order
        if isempty(gmaxcons)
            maxcons=ones(1,size(popG,2));
        else
            maxcons=gmaxcons;
        end
        popG(popG<0)=0;
        cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
        [~,ipf]=sortrows([-popFit, -cons],[2, 1]);
        newPop(ipf(1:numReplace),:)=replacePool;
        
    end
    for inp=1:NP
        [newPopFit(inp,1),newPopG(inp,:),changeoccur]=evaluate(newPop(inp,:),casedata);
    end
    
elseif method == 0
    newPop=pop;
    for inp=1:NP
        [newPopFit(inp,1),newPopG(inp,:),changeoccur]=evaluate(newPop(inp,:),casedata);
    end

    
elseif method == 1 || method == 2 
    nmfe=5;
    value.radius=0.08;
    value.nfe=nmfe;
    replacePool=retrieveMem_new(g_caseconfig.loads',g_caseconfig.PG', value);
    
    %% replace strategy
    numReplace = size(replacePool, 1);
    % numReplace = numSimilarMem + numImmigrants;
    para=2;
    initSize=2*NP;
    num = initSize-(NP+numReplace);
    if num > 0
        [rndPop] = initialSwarm(num,bound,DIM,2);
    else
        rndPop=[];
        initSize=(NP+numReplace);
    end
    newPop=[pop;replacePool;rndPop];
    popFit=zeros(initSize,1);
    popG=repmat(popG,para,1);
    for i=1:initSize
        [popFit(i,1),popG(i,:),changeoccur] = evaluate(newPop(i,:),casedata);
    end
    
    % sort the swarm in descending order
    if isempty(gmaxcons)
        maxcons=ones(1,size(popG,2));
    else
        maxcons=gmaxcons;
    end
    popG(popG<0)=0;
    cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
    [~,ipf]=sortrows([popFit, cons],[2, 1]);
    
    newPop=newPop(ipf(1:NP),:);
    newPopFit=popFit(ipf(1:NP),:);
    newPopG=popG(ipf(1:NP),:);
    
elseif method >= 6
    %����������ǰ��Ⱥ
     if usearchive ==0%%������
         memory_size =numel(memorynow);
         if memory_size < 2 
            nmfe=5;
            value.radius=0.08;
            value.nfe=nmfe;
            replacePool=retrieveMem_new(g_caseconfig.loads',g_caseconfig.PG', value);
            %% replace strategy
            numReplace = size(replacePool, 1);
            % numReplace = numSimilarMem + numImmigrants;
            para=2;
            initSize=2*NP;
            num = initSize-(NP+numReplace);
            if num > 0
                [rndPop] = initialSwarm(num,bound,DIM,2);
            else
                rndPop=[];
                initSize=(NP+numReplace);
            end
            newPop=[pop;replacePool;rndPop];
            popFit=zeros(initSize,1);
            popG=repmat(popG,para,1);
            for i=1:initSize
                [popFit(i,1),popG(i,:),changeoccur] = evaluate(newPop(i,:),casedata);
            end
            % sort the swarm in descending order
            if isempty(gmaxcons)
                maxcons=ones(1,size(popG,2));
            else
                maxcons=gmaxcons;
            end
            popG(popG<0)=0;
            cons=sum(popG./repmat(maxcons,initSize,1),2)./sum(1./maxcons);
            [~,ipf]=sortrows([popFit, cons],[2, 1]);

            newPop=newPop(ipf(1:NP),:);
            newPopFit=popFit(ipf(1:NP),:);
            newPopG=popG(ipf(1:NP),:);
            return;
         end
         memory = memorynow;%�������ռ����㹻�ĵ�ǰ������Ϣʱ�����Ǹ���ʹ�����ڵ����µõ�����
         [mu_sorted, mu_max, mu_last_env] = fuzzy_similarity(g_caseconfig.loads',g_caseconfig.PG');
         [N_pre, N_rnd, N_mem, N_replaced, MemIdSet] = determine_pop_percentage(mu_sorted, mu_max, mu_last_env, NP);
        %% ��֯prePop
        if N_pre>0
            for i=1:NP
                [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata);
             end
            %�Ÿ���
            if isempty(gmaxcons)
                maxcons=ones(1,size(popG,2));
            else
                maxcons=gmaxcons;
            end
            popG(popG<0)=0;
            cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
            [~,index]=sortrows([popFit, cons],[2, 1]);    
            pop=pop(index(1:NP),:);
            popFit=popFit(index(1:NP),:);
            popG=popG(index(1:NP),:);
            prePop=pop(1:N_pre,:);
            prePopFit=popFit(1:N_pre,:);
            prePopG=popG(1:N_pre,:);
        else
            prePop=[];
            prePopFit=[];
            prePopG=[];
        end
       %% ��֯memPop
        num_seed=0;
        num_mem=0;
        %���յ�mem
        memPop=[];
        %�м�ͼ�¼1
        memPop1=[];
        memPopFit1=[];
        %�м��¼2
        memPop2=[];
        memPopFit2=[];
        %�м��¼3
        memPop3=[];
        memPopFit3=[];
        memPopCons3=[];
        for id = MemIdSet%�ȿ��������ӵĸ��幻����
             %��¼1 ��������
             num_seed=num_seed+memory(id).LMsize;
             memPop1=[memPop1;memory(id).localMemory];
             memPopFit1=[memPopFit1;memory(id).LMFit];
             %��¼2 ���и���
             num_mem=num_mem+memory(id).memsize;
             memPop2=[memPop2;memory(id).memPop];
             memPopFit2=[memPopFit2;memory(id).memPopFit];
             %��¼3 ��������
             memPop3=[memPop3;memory(id).pop];
             memPopFit3=[memPopFit3;memory(id).popFit];
             memPopCons3=[memPopCons3;memory(id).popG];
         end
         if num_seed>=N_mem
             %����
             [~,index1]=sortrows(memPopFit1);
             memPop=memPop1(index1(1:N_mem),:);
         else         
                 memPop= [memPop1;memPop2];
                 [~,index2]=sortrows([memPopFit1;memPopFit2]);
                 memPop=memPop(index2,:);
            if num_mem+num_seed>=N_mem
                 memPop=memPop(index2(1:N_mem),:);
            else
                   X=N_mem-(num_mem+num_seed);
                   if isempty(gmaxcons)
                        maxcons=ones(1,size(memPopCons3,2));
                   else
                        maxcons=gmaxcons;
                   end
                   memPopCons3=sum(memPopCons3,2);
                   [~,ipf]=sortrows(memPopCons3);
                   memPop3=memPop3(ipf(1:X),:);            
                   memPop=[memPop;memPop3];           
             end
         end
        [memPopFit,memPopG] = evaluate_cut(memPop,casedata);
        %% ע�������
         N_rnd=max(N_rnd,NP*0.2);
        if N_rnd>0
            rndPopFit=zeros(NP,1);
            rndPopG=popG;
            [rndPop] = initialSwarm(NP,bound,DIM,2);%���NP?
            % ������Ӧ��
            for i=1:NP
                [rndPopFit(i,1),rndPopG(i,:),changeoccur] = evaluate(rndPop(i,:),casedata);
            end
            % �����Ⱥ����
            if isempty(gmaxcons)
                maxcons=ones(1,size(rndPopG,2));
            else
                maxcons=gmaxcons;
            end
            rndPopG(rndPopG<0)=0;
            cons=sum(rndPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
            [~,ipf]=sortrows([rndPopFit, cons],[2, 1]);
            %
            rndPop=rndPop(ipf(1:N_rnd),:);
            rndPopFit=rndPopFit(ipf(1:N_rnd),:);
            rndPopG=rndPopG(ipf(1:N_rnd),:);
        else
            rndPop=[];
            rndPopFit=[];
            rndPopG=[];
        end
          %% ��֯����newPop    
        newPop=[prePop;memPop;rndPop];
        newPopFit=[prePopFit;memPopFit;rndPopFit];
        newPopG=[prePopG;memPopG;rndPopG];
        %����һ�´�С
        newPop=newPop(1:NP,:);
        newPopFit= newPopFit(1:NP,:);
        newPopG=newPopG(1:NP,:);
        %����
        %��������
        newPopG(newPopG<0)=0;
        if isempty(gmaxcons)
            maxcons=ones(1,size(newPopG,2));
        else
            maxcons=gmaxcons;
        end
        cons=sum(newPopG./repmat(maxcons,size(newPopG,1),1),2)./sum(1./maxcons);
        [~,index]=sortrows([newPopFit, cons],[2, 1]);    
        newPop=newPop(index(1:NP),:);
        newPopFit=newPopFit(index(1:NP),:);
        newPopG=newPopG(index(1:NP),:);   
     else
         [mu_sorted, mu_max, mu_last_env] = fuzzy_similarity(g_caseconfig.loads',g_caseconfig.PG');
         [N_pre, N_rnd, N_mem, N_replaced, MemIdSet] = determine_pop_percentage(mu_sorted, mu_max, mu_last_env, NP);
        %% ��֯prePop
        if N_pre>0
            for i=1:NP
                [popFit(i,1),popG(i,:)] = evaluate(pop(i,:),casedata);
             end
            %�Ÿ���
            if isempty(gmaxcons)
                maxcons=ones(1,size(popG,2));
            else
                maxcons=gmaxcons;
            end
            popG(popG<0)=0;
            cons=sum(popG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
            [~,index]=sortrows([popFit, cons],[2, 1]);    
            pop=pop(index(1:NP),:);
            popFit=popFit(index(1:NP),:);
            popG=popG(index(1:NP),:);
            prePop=pop(1:N_pre,:);
            prePopFit=popFit(1:N_pre,:);
            prePopG=popG(1:N_pre,:);
        else
            prePop=[];
            prePopFit=[];
            prePopG=[];
        end
       %% ��֯memPop
        num_seed=0;
        num_mem=0;
        %���յ�mem
        memPop=[];
        %�м�ͼ�¼1
        memPop1=[];
        memPopFit1=[];
        %�м��¼2
        memPop2=[];
        memPopFit2=[];
        %�м��¼3
        memPop3=[];
        memPopFit3=[];
        memPopCons3=[];
        for id = MemIdSet%�ȿ��������ӵĸ��幻����
             %��¼1 ��������
             num_seed=num_seed+memory(id).LMsize;
             memPop1=[memPop1;memory(id).localMemory];
             memPopFit1=[memPopFit1;memory(id).LMFit];
             %��¼2 ���и���
             num_mem=num_mem+memory(id).memsize;
             memPop2=[memPop2;memory(id).memPop];
             memPopFit2=[memPopFit2;memory(id).memPopFit];
             %��¼3 ��������
             memPop3=[memPop3;memory(id).pop];
             memPopFit3=[memPopFit3;memory(id).popFit];
             memPopCons3=[memPopCons3;memory(id).popG];
         end
         if num_seed>=N_mem
             %����
             [~,index1]=sortrows(memPopFit1);
             memPop=memPop1(index1(1:N_mem),:);
         else         
                 memPop= [memPop1;memPop2];
                 [~,index2]=sortrows([memPopFit1;memPopFit2]);
                 memPop=memPop(index2,:);
            if num_mem+num_seed>=N_mem
                 memPop=memPop(index2(1:N_mem),:);
            else
                   X=N_mem-(num_mem+num_seed);
                   if isempty(gmaxcons)
                        maxcons=ones(1,size(memPopCons3,2));
                   else
                        maxcons=gmaxcons;
                   end
                   memPopCons3=sum(memPopCons3,2);
                   [~,ipf]=sortrows(memPopCons3);
                   memPop3=memPop3(ipf(1:X),:);            
                   memPop=[memPop;memPop3];           
             end
         end
        [memPopFit,memPopG] = evaluate_cut(memPop,casedata);
        %% ע�������
         N_rnd=max(N_rnd,NP*0.2);
        if N_rnd>0
            rndPopFit=zeros(NP,1);
            rndPopG=popG;
            [rndPop] = initialSwarm(NP,bound,DIM,2);%���NP?
            % ������Ӧ��
            for i=1:NP
                [rndPopFit(i,1),rndPopG(i,:),changeoccur] = evaluate(rndPop(i,:),casedata);
            end
            % �����Ⱥ����
            if isempty(gmaxcons)
                maxcons=ones(1,size(rndPopG,2));
            else
                maxcons=gmaxcons;
            end
            rndPopG(rndPopG<0)=0;
            cons=sum(rndPopG./repmat(maxcons,NP,1),2)./sum(1./maxcons);
            [~,ipf]=sortrows([rndPopFit, cons],[2, 1]);
            %
            rndPop=rndPop(ipf(1:N_rnd),:);
            rndPopFit=rndPopFit(ipf(1:N_rnd),:);
            rndPopG=rndPopG(ipf(1:N_rnd),:);
        else
            rndPop=[];
            rndPopFit=[];
            rndPopG=[];
        end
          %% ��֯����newPop    
        newPop=[prePop;memPop;rndPop];
        newPopFit=[prePopFit;memPopFit;rndPopFit];
        newPopG=[prePopG;memPopG;rndPopG];
        %����һ�´�С
        newPop=newPop(1:NP,:);
        newPopFit= newPopFit(1:NP,:);
        newPopG=newPopG(1:NP,:);
        %����
        %��������
        newPopG(newPopG<0)=0;
        if isempty(gmaxcons)
            maxcons=ones(1,size(newPopG,2));
        else
            maxcons=gmaxcons;
        end
        cons=sum(newPopG./repmat(maxcons,size(newPopG,1),1),2)./sum(1./maxcons);
        [~,index]=sortrows([newPopFit, cons],[2, 1]);    
        newPop=newPop(index(1:NP),:);
        newPopFit=newPopFit(index(1:NP),:);
        newPopG=newPopG(index(1:NP),:); 
     end
     
 end
%%
statsafterchange();
end


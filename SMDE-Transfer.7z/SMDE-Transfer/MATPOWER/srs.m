function pop=srs(pop,off,p)

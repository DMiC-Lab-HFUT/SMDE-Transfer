function [fit,conv]=evaluate_cut(v,casedata)
global nfe;
tmp=size(v);
popsize=tmp(1);
fit=zeros(popsize,1);
conv=zeros(popsize,3);
nfe=nfe+popsize;
for i=1:popsize
    if (strcmpi(casedata,'case30') || strcmpi(casedata,'dcase30'))
        [fit(i,:),conv(i,:)] = rpflow30(v(i,:),casedata);
    elseif(strcmpi(casedata,'case57') || strcmpi(casedata,'dcase57'))
        [fit(i,:),conv(i,:)] = rpflow57(v(i,:),casedata);
    elseif(strcmpi(casedata,'case118') || strcmpi(casedata,'dcase118'));
        [fit(i,:),conv(i,:)] = rpflow118(v(i,:),'dCase118');
    else
        disp('wrong casedata');
        keyboard;
    end
end
end
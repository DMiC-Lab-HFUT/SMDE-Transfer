function [dis_max]=estimate_dis_max()
global g_caseconfig;
global cgen;

global case_renewablePower;
global s0 s5;
% RandStream.setGlobalStream(s5);


if isempty(case_renewablePower)
    case_renewablePower=1;
end

TimesRnd = 100;

baseloads=g_caseconfig.baseloads;
delta=g_caseconfig.sev;
loads=baseloads.*( (2.*rand(size(baseloads))-1).*delta ) + baseloads;
numDynGen = numel(cgen);

PG=zeros(TimesRnd, numDynGen);
PD=zeros(TimesRnd, numel(baseloads));

for loop = 1 : TimesRnd
    baseloads=g_caseconfig.baseloads;
    delta=rand(s5);%g_caseconfig.sev;
    PD(loop,:)=baseloads.*( (2.*rand(s5, size(baseloads))-1).*delta ) + baseloads;
end

%case 1:ģ���������

for loop = 1: TimesRnd
    if case_renewablePower == 1
%         a=11.0086;
%         b=1.9622;
%         v=wblrnd(a,b,numDynGen, 1);%����Τ���ֲ��������
%         vci=4;
%         vrate=13.61;
%         vco=25;
        Prate = 40;
        
        vec = rand(s5, numDynGen, 1);
        PG(loop, :) = Prate * vec; 
        
%         for i=1:numDynGen
%             if v(i) <= vrate && v(i) >= vci
%                 PG(loop, i) = Prate * (v(i)-vci)/(vrate-vci);
%             elseif v(i) >= vrate && v(i) <= vco
%                 PG(loop, i) = Prate;
%             else
%                 PG(loop, i) = 0;
%             end
%         end
    else
        % case 2:ģ���������
%         a=0.9;
%         b=0.85;
        r_max=0.393;
        vec = rand(s5, numDynGen, 1);
%         vec=betarnd(a,b,numDynGen, 1);%����Beta�ֲ��������
        
        r=vec*r_max;
        A=500;
        yita=0.14;
        PG(loop, :)=r*A*yita;
    end
end

envPars=[PG, PD];
%distance calculation
distanceMatrix=zeros(TimesRnd,TimesRnd);
for i=1:TimesRnd
    distanceMatrix(i,i+1:TimesRnd) = pdist2(envPars(i,:), envPars(i+1:TimesRnd,:));
end
distanceMatrix=distanceMatrix+distanceMatrix';

dis_max=sum(sum(distanceMatrix))/(TimesRnd*TimesRnd);

% RandStream.setGlobalStream(s0);

end


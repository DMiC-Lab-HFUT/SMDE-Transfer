function selected=SUS(probs,NP)
global s1;
% Selection operator: stochastic universal sampling (SUS) algorithm
% Original literature: 
% J. E. Baker, "Reducing bias and inefficiency in the selection algorithm",
% in Proc. 2nd Int. Conf. Genetic Algorithms, 1987, pp. 14-21.
probs=probs.*(NP/sum(probs));
rr=rand(s1);
spacing=1;
partsum=0;
selected=[];
for i=1:numel(probs)
    partsum=partsum+probs(i);
    while rr<partsum
        selected=[selected,i];
        rr=rr+spacing;
    end
end
end

